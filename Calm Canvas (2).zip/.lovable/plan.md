## Phase 1B — Operative Kernschleife (Miriam-Test bis Tap 1)

Ziel: Miriam loggt sich ein, sieht in <3 Sekunden die richtige Mission, kann mit 1 Tap "Abgeholt" posten. Sandra sieht es live. Priya liest einen menschlichen Satz statt eines Statuscodes.

Keine generischen Komponenten. Drei domänenspezifische Surfaces, jede an einen User gebunden.

---

### 1. Greeter Action Surface — `/_authenticated/greeter`

Neue Route (ersetzt Greeter-Sektion im aktuellen `/portal` für Greeter-Rolle, oder wird vom Portal-Dispatcher dorthin geroutet).

**Server Function (neu in `portal.functions.ts`):** `getGreeterTodayMission`
- Sucht aktive Mission für `auth.uid()` über `mission_assignments` (role='greeter', unassigned_at IS NULL), ordered by `scheduled_arrival ASC`, nimmt die erste nicht-completed.
- Joint: talent profile (full_name, photo_url, languages, home_country), mission flight fields, accommodation_address, offene Blocker.
- Liefert auch die letzten 5 *kuratierten* Events (whitelist: GREETER_ASSIGNED, FLIGHT_DELAYED, TALENT_PICKED_UP, EN_ROUTE, HANDOVER_COMPLETED, BLOCKER_SET, BLOCKER_RESOLVED).

**Komponente `GreeterMissionCard`** (`src/components/greeter/GreeterMissionCard.tsx`), strikt diese Reihenfolge:

```
[Foto groß]   Priya Sharma
              IN aus Mumbai · Hindi, English
              ─────────────────────
              AI 120 · ETA 14:25
              DUS · Terminal A · Gate C14
              ─────────────────────
              Adresse: Königsallee 12, Düsseldorf

[ PRIMARY TAP — kontextabhängig ]
  → "Abgeholt"           wenn status=confirmed/in_progress ohne PICKED_UP
  → "Unterwegs zur Unterkunft" wenn PICKED_UP ohne EN_ROUTE
  → "Übergabe erledigt"  wenn EN_ROUTE ohne HANDOVER_COMPLETED

[ Secondary: "Blocker melden" — öffnet Sheet mit Grund-Textfeld ]

──── danach erst: ────
Nächster Schritt (1 Zeile, menschlich)
Kuratierte Timeline (max 5, leise)
```

Tap → `postMissionEvent({ kind: 'TALENT_PICKED_UP', ... })` → optimistic update, query invalidate. Kein Modal, keine Bestätigung, kein Toast-Spam — nur stiller State-Wechsel + neuer Primary-Tap.

**Wenn keine Mission heute:** Ein Satz, keine leere Tabelle. „Heute keine Ankunft. Nächste: Do 28.05., Priya Sharma, AI 120."

---

### 2. Company Decision Surface — `/_authenticated/company/missions/$missionId`

Neue Datei `src/routes/_authenticated/company/missions.$missionId.tsx`.

**Server Function:** `getCompanyMissionDetail(missionId)` — RLS regelt Zugriff.
Liefert: mission core + talent (Name, Foto, Sprache, Herkunft), aktueller Greeter (assignment + profile), **alle offenen Blocker**, last meaningful event, derived „next step"-Text, kuratierte Timeline.

**Komponente `CompanyMissionSummary`** — Decision-First Layout:

```
Priya Sharma · Ankunft Do 28.05. 14:25 DUS
──────────────────────────────────────────
STATUS         in progress
BLOCKER        ⚠ Visum-Kopie fehlt seit 2 Tagen   [Owner: Sandra]
NEXT STEP      Greeter Miriam holt Priya am Gate C14 ab
LAST UPDATE    Miriam · vor 12 Min · "Bin am Terminal"
OWNER          Miriam Klein (Greeter) · +49 …

──── wenn KEIN Blocker: ────
✓ Alles auf Kurs. Nächster Meilenstein: Abholung in 4h.
```

Erst darunter: kuratierte Timeline (max 10, mit „Mehr anzeigen"), Dokumente-Liste, Talent-Profil-Card.

Blocker-Block ist die *größte* Fläche oben, wenn vorhanden — explizit beruhigend grün, wenn nicht.

Verlinkt von der existierenden Company-Übersicht im Portal (Mission-Zeilen → Detail-Route).

---

### 3. Talent Next-Step Panel — auf `/_authenticated/portal` für Talent-Rolle

**Komponente `TalentNextStepPanel`** (`src/components/talent/TalentNextStepPanel.tsx`).

Keine Statuscodes. Status → Satz-Mapping (Single Source: `src/lib/talentCopy.ts`):

| Mission-Zustand | Satz (DE) |
|---|---|
| confirmed + greeter assigned | „Miriam wird dich am Flughafen abholen. Sie spricht Deutsch und Englisch." |
| FLIGHT_DELAYED event | „Wir haben deine neue Ankunftszeit gesehen. Miriam ist informiert." |
| TALENT_PICKED_UP | „Du bist abgeholt. Nächster Schritt: Fahrt zur Unterkunft." |
| EN_ROUTE | „Ihr seid unterwegs zur Königsallee 12, Düsseldorf." |
| HANDOVER_COMPLETED | „Angekommen. Ruh dich aus — morgen meldet sich deine Ansprechpartnerin." |
| Blocker offen, owner=talent | „Bitte lade noch deine Visum-Kopie hoch. Wir brauchen sie bis Mittwoch." |

EN-Toggle vorbereitet (Map `de` / `en`), Default aus `profile.locale`. Kein i18n-Framework — flache Map reicht für Phase 1B.

Darunter ein kleiner Block: „Wer hilft dir" (Greeter-Name + Foto + Sprache), „Wo du hin wirst" (Adresse). Keine Timeline für Talent.

---

### 4. Realtime-Light (eine Subscription, kein Framework)

In `GreeterMissionCard` und `CompanyMissionSummary`: ein einzelnes `supabase.channel` auf `mission_events` filtered nach `mission_id`, invalidate-only (`queryClient.invalidateQueries`). Kein Payload-Merge, keine Client-State-Tricks. Postgres-Realtime auf `mission_events` aktivieren (Migration).

---

### 5. Curation: Event-Whitelist

`src/lib/eventTaxonomy.ts`:
- `OPERATIONAL_EVENTS` = Whitelist sichtbarer Events
- `eventToHumanLine(event, audience: 'company' | 'greeter' | 'talent')` — eine Funktion, drei Tonalitäten
- Alle internen Events (z.B. `PROFILE_UPDATED`, falls je vorhanden) werden gefiltert.

---

### Was bewusst NICHT in 1B kommt
- Document-Upload (Storage-Bucket) — Phase 3
- Notifications/Email — später
- Vollständige i18n-Pipeline — flache Map reicht
- Chat — nicht jetzt
- PWA/Offline — Phase 4
- Generische Komponenten-Abstraktionen

---

### Migration (klein)
Nur: `ALTER PUBLICATION supabase_realtime ADD TABLE public.mission_events;` und `... ADD TABLE public.blockers;`. Keine Schema-Änderungen.

---

### Dateien (geschätzt 10)

**Neu:**
- `src/routes/_authenticated/greeter.tsx`
- `src/routes/_authenticated/company/missions.$missionId.tsx`
- `src/components/greeter/GreeterMissionCard.tsx`
- `src/components/company/CompanyMissionSummary.tsx`
- `src/components/talent/TalentNextStepPanel.tsx`
- `src/lib/eventTaxonomy.ts`
- `src/lib/talentCopy.ts`
- `supabase/migrations/<ts>_realtime.sql`

**Edit:**
- `src/lib/portal.functions.ts` (drei neue Read-Functions: `getGreeterTodayMission`, `getCompanyMissionDetail`, `getTalentNextStep`)
- `src/routes/_authenticated/portal.tsx` (Greeter-Rolle → Redirect/Render `GreeterMissionCard`; Talent-Rolle → `TalentNextStepPanel`; Company-Rolle → Mission-Zeilen verlinken zur Detail-Route)

Akzeptanz: Sandra erstellt Mission (über bestehende `createMission`-Function via temp. Admin-Tool oder Seed) → Miriam loggt ein → sieht Mission sofort → tap „Abgeholt" → Sandra-Tab updated <2s → Priya sieht „Du bist abgeholt".
