-- =====================================================
-- BLOCKERS — First-Class-Entity
-- =====================================================
CREATE TABLE public.blockers (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  mission_id uuid NOT NULL,
  reason text NOT NULL,
  payload jsonb NOT NULL DEFAULT '{}'::jsonb,
  owner_user_id uuid,
  owner_role app_role,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz,
  resolved_by uuid,
  is_demo boolean NOT NULL DEFAULT false
);
CREATE INDEX idx_blockers_mission ON public.blockers(mission_id);
CREATE INDEX idx_blockers_open ON public.blockers(mission_id) WHERE resolved_at IS NULL;

GRANT SELECT, INSERT, UPDATE ON public.blockers TO authenticated;
GRANT ALL ON public.blockers TO service_role;
ALTER TABLE public.blockers ENABLE ROW LEVEL SECURITY;

CREATE POLICY "read blockers of visible missions"
  ON public.blockers FOR SELECT TO authenticated
  USING (public.can_view_mission(mission_id, auth.uid()));

CREATE POLICY "insert blockers on visible missions"
  ON public.blockers FOR INSERT TO authenticated
  WITH CHECK (
    created_by = auth.uid()
    AND public.can_view_mission(mission_id, auth.uid())
  );

CREATE POLICY "update blockers on visible missions"
  ON public.blockers FOR UPDATE TO authenticated
  USING (public.can_view_mission(mission_id, auth.uid()))
  WITH CHECK (public.can_view_mission(mission_id, auth.uid()));

-- =====================================================
-- MISSION_ASSIGNMENTS
-- =====================================================
CREATE TABLE public.mission_assignments (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  mission_id uuid NOT NULL,
  user_id uuid NOT NULL,
  role app_role NOT NULL,
  assigned_by uuid,
  assigned_at timestamptz NOT NULL DEFAULT now(),
  unassigned_at timestamptz,
  is_demo boolean NOT NULL DEFAULT false
);
CREATE INDEX idx_assignments_mission ON public.mission_assignments(mission_id);
CREATE INDEX idx_assignments_user_active ON public.mission_assignments(user_id) WHERE unassigned_at IS NULL;

GRANT SELECT, INSERT, UPDATE ON public.mission_assignments TO authenticated;
GRANT ALL ON public.mission_assignments TO service_role;
ALTER TABLE public.mission_assignments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "read assignments of visible missions"
  ON public.mission_assignments FOR SELECT TO authenticated
  USING (public.can_view_mission(mission_id, auth.uid()));

CREATE POLICY "admin or company manages assignments"
  ON public.mission_assignments FOR INSERT TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
    OR EXISTS (
      SELECT 1 FROM public.missions m
      WHERE m.id = mission_assignments.mission_id
        AND m.company_id IN (SELECT public.user_company_ids(auth.uid()))
    )
  );

CREATE POLICY "admin or company unassigns"
  ON public.mission_assignments FOR UPDATE TO authenticated
  USING (
    public.is_admin(auth.uid())
    OR EXISTS (
      SELECT 1 FROM public.missions m
      WHERE m.id = mission_assignments.mission_id
        AND m.company_id IN (SELECT public.user_company_ids(auth.uid()))
    )
  );

-- =====================================================
-- MISSION_EVENTS — Append-Only, mit actor_role + payload
-- =====================================================
ALTER TABLE public.mission_events
  ADD COLUMN IF NOT EXISTS actor_role app_role,
  ADD COLUMN IF NOT EXISTS payload jsonb NOT NULL DEFAULT '{}'::jsonb;

-- INSERT-Policy (SELECT bereits vorhanden). Append-only: kein UPDATE/DELETE.
CREATE POLICY "post events on visible missions"
  ON public.mission_events FOR INSERT TO authenticated
  WITH CHECK (
    created_by = auth.uid()
    AND public.can_view_mission(mission_id, auth.uid())
  );

-- =====================================================
-- MISSIONS — operative Felder + Write-Policies
-- =====================================================
ALTER TABLE public.missions
  ADD COLUMN IF NOT EXISTS airline text,
  ADD COLUMN IF NOT EXISTS flight_number text,
  ADD COLUMN IF NOT EXISTS arrival_airport text,
  ADD COLUMN IF NOT EXISTS arrival_terminal text,
  ADD COLUMN IF NOT EXISTS arrival_gate text,
  ADD COLUMN IF NOT EXISTS scheduled_arrival timestamptz,
  ADD COLUMN IF NOT EXISTS actual_arrival timestamptz,
  ADD COLUMN IF NOT EXISTS accommodation_address text;

CREATE POLICY "admin or company creates missions"
  ON public.missions FOR INSERT TO authenticated
  WITH CHECK (
    public.is_admin(auth.uid())
    OR (company_id IS NOT NULL AND company_id IN (SELECT public.user_company_ids(auth.uid())))
  );

CREATE POLICY "admin, company or assigned greeter updates missions"
  ON public.missions FOR UPDATE TO authenticated
  USING (
    public.is_admin(auth.uid())
    OR (company_id IS NOT NULL AND company_id IN (SELECT public.user_company_ids(auth.uid())))
    OR greeter_id = auth.uid()
  )
  WITH CHECK (
    public.is_admin(auth.uid())
    OR (company_id IS NOT NULL AND company_id IN (SELECT public.user_company_ids(auth.uid())))
    OR greeter_id = auth.uid()
  );

-- =====================================================
-- TALENTS — operative Felder + Write-Policies
-- =====================================================
ALTER TABLE public.talents
  ADD COLUMN IF NOT EXISTS photo_url text,
  ADD COLUMN IF NOT EXISTS languages text[] NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS recruiter_notes text;

CREATE POLICY "talent or company or admin inserts talent"
  ON public.talents FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    OR public.is_admin(auth.uid())
    OR (company_id IS NOT NULL AND company_id IN (SELECT public.user_company_ids(auth.uid())))
  );

CREATE POLICY "talent or company or admin updates talent"
  ON public.talents FOR UPDATE TO authenticated
  USING (
    user_id = auth.uid()
    OR public.is_admin(auth.uid())
    OR (company_id IS NOT NULL AND company_id IN (SELECT public.user_company_ids(auth.uid())))
  )
  WITH CHECK (
    user_id = auth.uid()
    OR public.is_admin(auth.uid())
    OR (company_id IS NOT NULL AND company_id IN (SELECT public.user_company_ids(auth.uid())))
  );

-- =====================================================
-- DOCUMENTS — UPDATE-Policy (z.B. Status auf received)
-- =====================================================
CREATE POLICY "owner or mission collaborators update documents"
  ON public.documents FOR UPDATE TO authenticated
  USING (
    owner_user_id = auth.uid()
    OR (mission_id IS NOT NULL AND public.can_view_mission(mission_id, auth.uid()))
  )
  WITH CHECK (
    owner_user_id = auth.uid()
    OR (mission_id IS NOT NULL AND public.can_view_mission(mission_id, auth.uid()))
  );