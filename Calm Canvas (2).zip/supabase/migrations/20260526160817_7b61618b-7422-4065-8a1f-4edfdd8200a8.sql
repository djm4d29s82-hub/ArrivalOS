ALTER PUBLICATION supabase_realtime ADD TABLE public.mission_events;
ALTER PUBLICATION supabase_realtime ADD TABLE public.blockers;
ALTER PUBLICATION supabase_realtime ADD TABLE public.missions;