
create type public.app_role as enum ('talent', 'greeter', 'company', 'admin');
create type public.mission_status as enum ('draft', 'confirmed', 'in_progress', 'completed', 'cancelled');

create table public.user_roles (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade not null,
  role public.app_role not null,
  created_at timestamptz not null default now(),
  unique (user_id, role)
);
alter table public.user_roles enable row level security;

create or replace function public.has_role(_user_id uuid, _role public.app_role)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.user_roles where user_id = _user_id and role = _role)
$$;

create or replace function public.is_admin(_user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select public.has_role(_user_id, 'admin')
$$;

create or replace function public.current_role_names()
returns text[] language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(role::text order by role), '{}') from public.user_roles where user_id = auth.uid()
$$;

create policy "users read own roles" on public.user_roles for select to authenticated
  using (user_id = auth.uid() or public.is_admin(auth.uid()));

-- PROFILES
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text,
  locale text not null default 'de',
  avatar_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
create policy "read all profiles when authenticated" on public.profiles for select to authenticated using (true);
create policy "users update own profile" on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, full_name)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', new.email));
  return new;
end; $$;

create trigger on_auth_user_created
  after insert on auth.users for each row execute function public.handle_new_user();

-- COMPANIES
create table public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  contact_email text,
  city text,
  created_at timestamptz not null default now()
);
alter table public.companies enable row level security;

create table public.company_members (
  company_id uuid references public.companies(id) on delete cascade not null,
  user_id uuid references auth.users(id) on delete cascade not null,
  primary key (company_id, user_id)
);
alter table public.company_members enable row level security;

create or replace function public.user_company_ids(_user_id uuid)
returns setof uuid language sql stable security definer set search_path = public as $$
  select company_id from public.company_members where user_id = _user_id
$$;

create policy "members read own company" on public.companies for select to authenticated
  using (id in (select public.user_company_ids(auth.uid())) or public.is_admin(auth.uid()));
create policy "members read own company members" on public.company_members for select to authenticated
  using (company_id in (select public.user_company_ids(auth.uid())) or public.is_admin(auth.uid()));

-- GREETERS
create table public.greeters (
  user_id uuid primary key references auth.users(id) on delete cascade,
  city text not null default '',
  languages text[] not null default '{}',
  bio text,
  available boolean not null default true,
  created_at timestamptz not null default now()
);
alter table public.greeters enable row level security;
create policy "anyone authenticated reads greeters" on public.greeters for select to authenticated using (true);
create policy "greeter updates own row" on public.greeters for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "greeter inserts own row" on public.greeters for insert to authenticated
  with check (user_id = auth.uid() or public.is_admin(auth.uid()));

-- TALENTS (table only; SELECT policy added after missions exists)
create table public.talents (
  user_id uuid primary key references auth.users(id) on delete cascade,
  company_id uuid references public.companies(id) on delete set null,
  home_country text,
  arrival_date date,
  city text,
  created_at timestamptz not null default now()
);
alter table public.talents enable row level security;

-- MISSIONS
create table public.missions (
  id uuid primary key default gen_random_uuid(),
  talent_id uuid references auth.users(id) on delete cascade not null,
  greeter_id uuid references auth.users(id) on delete set null,
  company_id uuid references public.companies(id) on delete set null,
  city text not null,
  status public.mission_status not null default 'draft',
  starts_at date,
  ends_at date,
  summary text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
alter table public.missions enable row level security;

create or replace function public.can_view_mission(_mission_id uuid, _user_id uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from public.missions m
    where m.id = _mission_id
      and (
        m.talent_id = _user_id
        or m.greeter_id = _user_id
        or m.company_id in (select public.user_company_ids(_user_id))
        or public.is_admin(_user_id)
      )
  )
$$;

create policy "mission visibility" on public.missions for select to authenticated
  using (
    talent_id = auth.uid()
    or greeter_id = auth.uid()
    or company_id in (select public.user_company_ids(auth.uid()))
    or public.is_admin(auth.uid())
  );

-- Talents SELECT policy (now that missions exists)
create policy "talent visibility" on public.talents for select to authenticated
  using (
    user_id = auth.uid()
    or company_id in (select public.user_company_ids(auth.uid()))
    or public.is_admin(auth.uid())
    or exists (select 1 from public.missions m where m.talent_id = talents.user_id and m.greeter_id = auth.uid())
  );

-- MISSION EVENTS
create table public.mission_events (
  id uuid primary key default gen_random_uuid(),
  mission_id uuid references public.missions(id) on delete cascade not null,
  kind text not null,
  title text not null,
  body text,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);
alter table public.mission_events enable row level security;
create policy "read events of visible missions" on public.mission_events for select to authenticated
  using (public.can_view_mission(mission_id, auth.uid()));

-- DOCUMENTS
create table public.documents (
  id uuid primary key default gen_random_uuid(),
  owner_user_id uuid references auth.users(id) on delete cascade not null,
  mission_id uuid references public.missions(id) on delete cascade,
  kind text not null,
  title text not null,
  status text not null default 'pending',
  storage_path text,
  created_at timestamptz not null default now()
);
alter table public.documents enable row level security;
create policy "read own or mission documents" on public.documents for select to authenticated
  using (
    owner_user_id = auth.uid()
    or (mission_id is not null and public.can_view_mission(mission_id, auth.uid()))
  );
create policy "insert own documents" on public.documents for insert to authenticated
  with check (owner_user_id = auth.uid());

-- MESSAGES
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  mission_id uuid references public.missions(id) on delete cascade not null,
  from_user_id uuid references auth.users(id) on delete set null not null,
  body text not null,
  created_at timestamptz not null default now()
);
alter table public.messages enable row level security;
create policy "read messages of visible missions" on public.messages for select to authenticated
  using (public.can_view_mission(mission_id, auth.uid()));
create policy "send message to visible mission" on public.messages for insert to authenticated
  with check (from_user_id = auth.uid() and public.can_view_mission(mission_id, auth.uid()));

-- INVOICES
create table public.invoices (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete cascade not null,
  mission_id uuid references public.missions(id) on delete set null,
  amount_cents integer not null default 0,
  currency text not null default 'EUR',
  status text not null default 'draft',
  issued_at date,
  created_at timestamptz not null default now()
);
alter table public.invoices enable row level security;
create policy "company reads own invoices" on public.invoices for select to authenticated
  using (company_id in (select public.user_company_ids(auth.uid())) or public.is_admin(auth.uid()));

-- SOPs
create table public.sops (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  audience public.app_role not null default 'greeter',
  created_at timestamptz not null default now()
);
alter table public.sops enable row level security;
create policy "audience reads sop" on public.sops for select to authenticated
  using (public.has_role(auth.uid(), audience) or public.is_admin(auth.uid()));

-- TOUCH updated_at
create or replace function public.touch_updated_at()
returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end; $$;
create trigger profiles_touch before update on public.profiles for each row execute function public.touch_updated_at();
create trigger missions_touch before update on public.missions for each row execute function public.touch_updated_at();
