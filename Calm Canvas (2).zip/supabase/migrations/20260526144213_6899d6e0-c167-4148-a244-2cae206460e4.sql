-- Add is_demo column
ALTER TABLE public.profiles      ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT false;
ALTER TABLE public.user_roles    ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT false;
ALTER TABLE public.companies     ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT false;
ALTER TABLE public.company_members ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT false;
ALTER TABLE public.talents       ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT false;
ALTER TABLE public.greeters      ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT false;
ALTER TABLE public.missions      ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT false;
ALTER TABLE public.mission_events ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT false;
ALTER TABLE public.documents     ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT false;
ALTER TABLE public.messages      ADD COLUMN IF NOT EXISTS is_demo boolean NOT NULL DEFAULT false;

-- Backfill: mark existing demo accounts and their data
WITH demo_users AS (
  SELECT id FROM auth.users WHERE email LIKE '%@neuland.app'
)
UPDATE public.profiles SET is_demo = true WHERE id IN (SELECT id FROM demo_users);

WITH demo_users AS (
  SELECT id FROM auth.users WHERE email LIKE '%@neuland.app'
)
UPDATE public.user_roles SET is_demo = true WHERE user_id IN (SELECT id FROM demo_users);

UPDATE public.companies SET is_demo = true WHERE name = 'Krane GmbH';

UPDATE public.company_members SET is_demo = true
  WHERE company_id IN (SELECT id FROM public.companies WHERE is_demo);

UPDATE public.talents SET is_demo = true
  WHERE user_id IN (SELECT id FROM auth.users WHERE email LIKE '%@neuland.app');

UPDATE public.greeters SET is_demo = true
  WHERE user_id IN (SELECT id FROM auth.users WHERE email LIKE '%@neuland.app');

UPDATE public.missions SET is_demo = true
  WHERE talent_id IN (SELECT id FROM auth.users WHERE email LIKE '%@neuland.app')
     OR greeter_id IN (SELECT id FROM auth.users WHERE email LIKE '%@neuland.app');

UPDATE public.mission_events SET is_demo = true
  WHERE mission_id IN (SELECT id FROM public.missions WHERE is_demo);

UPDATE public.documents SET is_demo = true
  WHERE mission_id IN (SELECT id FROM public.missions WHERE is_demo)
     OR owner_user_id IN (SELECT id FROM auth.users WHERE email LIKE '%@neuland.app');

UPDATE public.messages SET is_demo = true
  WHERE mission_id IN (SELECT id FROM public.missions WHERE is_demo);

-- Indexes for fast filtering
CREATE INDEX IF NOT EXISTS idx_missions_is_demo ON public.missions(is_demo);
CREATE INDEX IF NOT EXISTS idx_mission_events_is_demo ON public.mission_events(is_demo);
CREATE INDEX IF NOT EXISTS idx_documents_is_demo ON public.documents(is_demo);
CREATE INDEX IF NOT EXISTS idx_messages_is_demo ON public.messages(is_demo);