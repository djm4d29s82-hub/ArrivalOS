import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/greeter")({
  head: () => ({
    meta: [
      { title: "Greeter werden — NeuLand" },
      { name: "description", content: "Werde Teil einer Bewegung, die echten Unterschied macht. Sei das erste freundliche Gesicht in einer neuen Stadt." },
      { property: "og:title", content: "Greeter werden — NeuLand" },
      { property: "og:description", content: "Sei das erste freundliche Gesicht." },
    ],
  }),
  component: Greeter,
});

function Greeter() {
  return (
    <>
      <section className="min-h-[72vh] flex items-center">
        <div className="mx-auto max-w-[1180px] px-6 md:px-10 py-24 md:py-32 w-full">
          <p className="nl-rise text-[11px] uppercase tracking-[0.28em] text-mid mb-10">Greeter werden</p>
          <h1 className="nl-rise-2 font-serif text-[clamp(40px,5.6vw,80px)] leading-[1.05] text-navy max-w-[18ch]">
            Sei das <em className="text-gold">erste</em> freundliche Gesicht.
          </h1>
          <p className="nl-rise-3 mt-10 max-w-xl text-lg text-mid leading-relaxed">
            Du kennst deine Stadt. Du magst Menschen. Du hast ein paar Stunden in der Woche.
            Mehr braucht es nicht, um jemandem den Start in einem fremden Land zu verändern.
          </p>
        </div>
      </section>

      <section className="border-t border-border">
        <div className="mx-auto max-w-[980px] px-6 md:px-10 py-32">
          <p className="text-[11px] uppercase tracking-[0.28em] text-gold mb-10">Wie es geht</p>
          <ol className="space-y-12">
            {[
              ["Bewerben", "Erzähl uns kurz von dir und deiner Stadt."],
              ["Kennenlernen", "Wir sprechen über deine Zeit, deine Sprachen, deine Lieblingsorte."],
              ["Match", "Wir verbinden dich mit jemandem, dessen Ankunft du begleiten wirst."],
              ["Begleiten", "Sechs Wochen — in deinem Rhythmus, persönlich, fair vergütet."],
            ].map(([title, body], i) => (
              <li key={title} className="grid grid-cols-[auto_1fr] gap-8 items-baseline">
                <span className="font-serif italic text-gold text-2xl">{String(i + 1).padStart(2, "0")}</span>
                <div>
                  <h3 className="font-serif text-2xl text-navy">{title}</h3>
                  <p className="mt-2 text-mid leading-relaxed">{body}</p>
                </div>
              </li>
            ))}
          </ol>
        </div>
      </section>

      <section className="border-t border-border bg-navy text-cream">
        <div className="mx-auto max-w-[1180px] px-6 md:px-10 py-32 md:py-40 text-center">
          <h2 className="font-serif text-[clamp(32px,4.4vw,60px)] leading-tight text-cream max-w-[20ch] mx-auto">
            <em className="text-gold">Werde</em> Teil einer Bewegung.
          </h2>
          <Link
            to="/kontakt"
            className="mt-12 inline-flex items-center gap-3 text-cream"
          >
            <span className="border-b border-cream pb-1 hover:border-gold hover:text-gold transition-colors">
              Jetzt bewerben
            </span>
            <span>→</span>
          </Link>
        </div>
      </section>
    </>
  );
}
