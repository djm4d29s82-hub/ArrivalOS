import { createFileRoute, redirect } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { PortalShell } from "@/components/portal/PortalShell";
import { CompanyMissionSummary } from "@/components/company/CompanyMissionSummary";

export const Route = createFileRoute("/_authenticated/company/missions/$missionId")({
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/login" });
  },
  head: () => ({ meta: [{ title: "Mission — NeuLand" }] }),
  component: MissionDetailPage,
});

function MissionDetailPage() {
  const { missionId } = Route.useParams();
  return (
    <PortalShell sectionLabel="Unternehmen" fullName={null} nav={[]}>
      <CompanyMissionSummary missionId={missionId} />
    </PortalShell>
  );
}
