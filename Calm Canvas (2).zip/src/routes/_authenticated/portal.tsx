import { createFileRoute, redirect, Link } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { PortalShell, PortalHeader, SummaryLine, GroupLabel, MetaRow, ListRow, MissionKernel, blockerTrailing } from "@/components/portal/PortalShell";
import { formatRelative, labelKind } from "@/lib/relativeTime";
import {
  getMyRoles,
  getTalentJourney,
  getTalentDocuments,
  getGreeterOverview,
  setGreeterAvailability,
  getCompanyOverview,
  getAdminOverview,
  claimTalentRole,
  getGreeterTodayMission,
} from "@/lib/portal.functions";
import { switchToDemoAccount, type DemoRole } from "@/lib/demo.functions";
import { GreeterMissionCard } from "@/components/greeter/GreeterMissionCard";
import { TalentNextStepPanel } from "@/components/talent/TalentNextStepPanel";

export const Route = createFileRoute("/_authenticated/portal")({
  beforeLoad: async () => {
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/login" });
  },
  head: () => ({ meta: [{ title: "Portal — NeuLand" }] }),
  component: Portal,
});

function Portal() {
  const fetchRoles = useServerFn(getMyRoles);
  const { data, isLoading } = useQuery({
    queryKey: ["my-roles"],
    queryFn: () => fetchRoles(),
  });

  if (isLoading || !data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-cream">
        <p className="text-mid text-sm italic">Einen Moment …</p>
      </div>
    );
  }

  const roles = data.roles;
  const primary = roles.includes("admin")
    ? "admin"
    : roles.includes("company")
    ? "company"
    : roles.includes("greeter")
    ? "greeter"
    : roles.includes("talent")
    ? "talent"
    : null;

  if (!primary) {
    return <NoRoleScreen />;
  }

  return <RolePortal role={primary} fullName={data.fullName} isAdmin={roles.includes("admin")} />;
}

function NoRoleScreen() {
  const qc = useQueryClient();
  const claim = useServerFn(claimTalentRole);
  const { mutate, isPending, error } = useMutation({
    mutationFn: () => claim(),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["my-roles"] }),
  });
  return (
    <div className="min-h-screen flex items-center justify-center bg-cream px-6 text-center">
      <div className="max-w-md">
        <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-8">Willkommen</p>
        <h1 className="font-serif text-3xl text-navy leading-tight">
          Dein Konto ist da. Lass uns als Talent loslegen.
        </h1>
        <p className="mt-6 text-mid leading-relaxed">
          Greeter, Unternehmen und Admins werden direkt vom NeuLand-Team eingerichtet. Du kannst hier als Talent starten.
        </p>
        <button
          onClick={() => mutate()}
          disabled={isPending}
          className="mt-10 text-navy disabled:opacity-50"
        >
          <span className="border-b border-navy pb-1 hover:border-gold hover:text-gold transition-colors">
            {isPending ? "Einen Moment …" : "Als Talent fortfahren"}
          </span>
        </button>
        {error && <p className="mt-6 text-sm text-mid italic">Das hat nicht geklappt. Bitte später erneut versuchen.</p>}
        <div className="pt-10 mt-10 border-t border-border">
          <button onClick={() => supabase.auth.signOut()} className="text-sm text-mid hover:text-navy transition-colors">
            Abmelden
          </button>
        </div>
      </div>
    </div>
  );
}

function RolePortal({ role, fullName, isAdmin }: { role: string; fullName: string | null; isAdmin: boolean }) {
  return (
    <div>
      <SessionBar isAdmin={isAdmin} />
      {role === "talent" && <TalentPortal fullName={fullName} />}
      {role === "greeter" && <GreeterPortal fullName={fullName} />}
      {role === "company" && <CompanyPortal fullName={fullName} />}
      {role === "admin" && <AdminPortal fullName={fullName} />}
      {!["talent", "greeter", "company", "admin"].includes(role) && (
        <PlaceholderPortal role={role} fullName={fullName} />
      )}
    </div>
  );
}

function SessionBar({ isAdmin }: { isAdmin: boolean }) {
  const switchFn = useServerFn(switchToDemoAccount);
  const [busy, setBusy] = useState<DemoRole | "out" | null>(null);
  const doSwitch = async (role: DemoRole) => {
    setBusy(role);
    try {
      const { email, password } = await switchFn({ data: { role } });
      await supabase.auth.signOut();
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      window.location.assign("/portal");
    } catch {
      setBusy(null);
    }
  };
  const logout = async () => {
    setBusy("out");
    await supabase.auth.signOut();
    window.location.assign("/login");
  };
  return (
    <div className="bg-cream border-b border-border">
      <div className="mx-auto max-w-[1180px] px-6 md:px-10 py-3 flex items-center justify-end gap-6 text-[11px] uppercase tracking-[0.28em] text-mid">
        {isAdmin && (
          <div className="flex items-center gap-4">
            <span>Wechseln zu</span>
            {(["talent", "greeter", "company", "admin"] as DemoRole[]).map((r) => (
              <button key={r} disabled={busy !== null} onClick={() => doSwitch(r)}
                className="hover:text-navy disabled:opacity-50 transition-colors">
                {busy === r ? "…" : r}
              </button>
            ))}
          </div>
        )}
        <button onClick={logout} disabled={busy !== null} className="hover:text-navy disabled:opacity-50 transition-colors">
          {busy === "out" ? "…" : "Abmelden"}
        </button>
      </div>
    </div>
  );
}

// =================== TALENT ===================
function TalentPortal({ fullName }: { fullName: string | null }) {
  const [tab, setTab] = useState<"journey" | "greeter" | "docs">("journey");

  return (
    <PortalShell sectionLabel="Talent" fullName={fullName} nav={[]}>
      <InlineNav
        items={[
          { id: "journey", label: "Deine Reise" },
          { id: "greeter", label: "Dein Greeter" },
          { id: "docs", label: "Dokumente" },
        ]}
        active={tab}
        onChange={(v) => setTab(v as any)}
      />
      <div key={tab} className="nl-quiet">
        {tab === "journey" && <TalentNextStepPanel />}
        {tab === "greeter" && <TalentGreeter />}
        {tab === "docs" && <TalentDocuments />}
      </div>
    </PortalShell>
  );
}

function TalentJourney() {
  const fn = useServerFn(getTalentJourney);
  const { data } = useQuery({ queryKey: ["talent-journey"], queryFn: () => fn() });

  if (!data) return <Empty>Einen Moment …</Empty>;
  if (!data.mission) {
    return (
      <PortalHeader
        eyebrow="Deine Reise"
        title="Bald geht es los."
        sub="Sobald dein Greeter feststeht, erscheint hier deine Zeitachse — Schritt für Schritt."
      />
    );
  }

  const m = data.mission;
  const greeter = data.greeter as any;
  const kernel = (data as any).kernel ?? null;
  return (
    <>
      <PortalHeader
        eyebrow={`${m.city} · ${labelStatus(m.status)}`}
        title="Deine Reise."
        sub={m.summary ?? undefined}
      />
      <section className="px-8 md:px-16 py-16 md:py-20 max-w-3xl">
        {greeter && (
          <div className="flex items-start gap-8 mb-16">
            <div className="h-24 w-24 shrink-0 bg-navy text-cream font-serif text-3xl flex items-center justify-center">
              {monogram(greeter.full_name)}
            </div>
            <div className="pt-2">
              <p className="text-[11px] uppercase tracking-[0.28em] text-mid">Dein Greeter</p>
              <p className="font-serif text-3xl text-navy mt-2 leading-tight">{greeter.full_name}</p>
              <p className="text-mid mt-2">wartet auf dich in {m.city}.</p>
            </div>
          </div>
        )}
        <div className="mb-20">
          <MissionKernel
            kernel={kernel}
            view="talent"
            size="lg"
            context={[
              m.city,
              m.starts_at ? `Ankunft ${formatDate(m.starts_at)}` : null,
              greeter ? `Begleitung durch ${greeter.full_name}` : null,
            ].filter(Boolean).join(" · ")}
          />
        </div>
        <GroupLabel>Eckdaten</GroupLabel>
        <div className="border-y border-border">
          <MetaRow label="Stadt" value={m.city} />
          <MetaRow label="Zeitraum" value={`${m.starts_at ?? "—"} → ${m.ends_at ?? "—"}`} />
          <MetaRow label="Dokumente offen" value={String(data.pendingDocsCount)} />
        </div>
      </section>
      <section className="px-8 md:px-16 pb-20 md:pb-28 max-w-3xl">
        <GroupLabel className="mt-8">Zeitachse</GroupLabel>
        <ol className="space-y-12">
          {data.events.map((e: any) => {
            const isFuture = new Date(e.created_at).getTime() > Date.now();
            return (
              <li key={e.id} className={`grid grid-cols-[7rem_1fr] gap-8 ${isFuture ? "border-l border-gold pl-6 -ml-6" : ""}`}>
                <span className="font-serif italic text-gold text-base pt-1">{formatRelative(e.created_at)}</span>
                <div>
                  <h3 className="font-serif text-xl text-navy leading-snug">{e.title}</h3>
                  {e.body && <p className="mt-2 text-mid leading-[1.7] text-[15px]">{e.body}</p>}
                  {e.created_by_name && (
                    <p className="mt-2 text-xs uppercase tracking-[0.2em] text-mid">von {e.created_by_name}</p>
                  )}
                </div>
              </li>
            );
          })}
          {data.events.length === 0 && <p className="text-mid italic">Die ersten Schritte stehen noch aus.</p>}
        </ol>
      </section>
    </>
  );
}

function TalentGreeter() {
  const fn = useServerFn(getTalentJourney);
  const { data } = useQuery({ queryKey: ["talent-journey"], queryFn: () => fn() });
  if (!data) return <Empty>Einen Moment …</Empty>;
  if (!data.greeter) {
    return <PortalHeader eyebrow="Dein Greeter" title="Wir suchen die richtige Person für dich." sub="Wir nehmen uns dafür die Zeit, die es braucht." />;
  }
  const g = data.greeter as any;
  return (
    <>
      <PortalHeader eyebrow="Dein Greeter" title={g.full_name ?? "Dein Greeter"} sub={`${g.city} · ${(g.languages ?? []).join(" · ")}`} />
      <section className="px-8 md:px-16 py-16 md:py-20 max-w-2xl">
        <p className="font-serif text-2xl text-navy leading-[1.55]">{g.bio}</p>
      </section>
    </>
  );
}

function TalentDocuments() {
  const fn = useServerFn(getTalentDocuments);
  const { data } = useQuery({ queryKey: ["talent-docs"], queryFn: () => fn() });
  const docs = data?.documents ?? [];
  const pending = docs.filter((d: any) => d.status !== "received");
  const received = docs.filter((d: any) => d.status === "received");

  return (
    <>
      <PortalHeader eyebrow="Dokumente" title="Was wir schon haben." sub="Und woran wir gemeinsam noch arbeiten." />
      <SummaryLine>{`${docs.length} insgesamt · ${pending.length} ausstehend · ${received.length} vorhanden`}</SummaryLine>
      <section className="px-8 md:px-16 py-16 md:py-20 max-w-3xl">
        {pending.length > 0 && (
          <>
            <GroupLabel>Ausstehend</GroupLabel>
            <ul className="border-y border-border divide-y divide-border mb-16">
              {pending.map((d: any) => (
                <li key={d.id}>
                  <ListRow
                    primary={<span className="font-serif text-xl text-navy">{d.title}</span>}
                    meta={<>{labelKind(d.kind)} · {formatDate(d.created_at)}</>}
                    trailing="ausstehend"
                  />
                </li>
              ))}
            </ul>
          </>
        )}
        {received.length > 0 && (
          <>
            <GroupLabel>Vorhanden</GroupLabel>
            <ul className="border-y border-border divide-y divide-border">
              {received.map((d: any) => (
                <li key={d.id}>
                  <ListRow
                    primary={<span className="font-serif text-xl text-navy">{d.title}</span>}
                    meta={<>{labelKind(d.kind)} · {formatDate(d.created_at)}</>}
                    trailing={<span className="text-gold">vorhanden</span>}
                  />
                </li>
              ))}
            </ul>
          </>
        )}
        {docs.length === 0 && <p className="text-mid italic">Noch nichts hinterlegt.</p>}
      </section>
    </>
  );
}

// =================== GREETER ===================
function GreeterPortal({ fullName }: { fullName: string | null }) {
  const [tab, setTab] = useState<"now" | "missions" | "profile">("now");
  return (
    <PortalShell sectionLabel="Greeter" fullName={fullName} nav={[]}>
      <InlineNav
        items={[
          { id: "now", label: "Aktuell" },
          { id: "missions", label: "Einsätze" },
          { id: "profile", label: "Profil" },
        ]}
        active={tab}
        onChange={(v) => setTab(v as any)}
      />
      <div key={tab} className="nl-quiet">
        {tab === "now" && <GreeterNow />}
        {tab === "missions" && <GreeterMissions />}
        {tab === "profile" && <GreeterProfile />}
      </div>
    </PortalShell>
  );
}

function GreeterNow() {
  const fn = useServerFn(getGreeterTodayMission);
  const qc = useQueryClient();
  const { data } = useQuery({ queryKey: ["greeter-today"], queryFn: () => fn() });
  const overviewFn = useServerFn(getGreeterOverview);
  const { data: overview } = useQuery({ queryKey: ["greeter-overview"], queryFn: () => overviewFn() });
  const toggle = useServerFn(setGreeterAvailability);
  const mut = useMutation({
    mutationFn: (available: boolean) => toggle({ data: { available } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["greeter-overview"] }),
  });
  const available = overview?.greeter?.available ?? false;
  return (
    <>
      <div className="px-8 md:px-12 border-b border-border flex items-center justify-between py-4 text-sm">
        <span className="text-[11px] uppercase tracking-[0.28em] text-mid">
          {available ? "Verfügbar" : "Pausiert"}
        </span>
        <button
          onClick={() => mut.mutate(!available)}
          disabled={mut.isPending}
          className="text-[11px] uppercase tracking-[0.28em] text-mid hover:text-navy disabled:opacity-50 transition-colors"
        >
          {available ? "Pausieren" : "Wieder verfügbar"}
        </button>
      </div>
      <GreeterMissionCard data={data ?? null} />
    </>
  );
}

function GreeterMissions() {
  const fn = useServerFn(getGreeterOverview);
  const { data } = useQuery({ queryKey: ["greeter-overview"], queryFn: () => fn() });
  const all = (data?.all ?? []) as any[];
  const groups: Array<{ label: string; items: any[] }> = [
    { label: "Laufend", items: all.filter((m) => m.status === "in_progress") },
    { label: "Bestätigt", items: all.filter((m) => m.status === "confirmed" || m.status === "draft") },
    { label: "Abgeschlossen", items: all.filter((m) => m.status === "completed" || m.status === "cancelled") },
  ];
  return (
    <>
      <PortalHeader eyebrow="Einsätze" title="Alles, was du begleitest." />
      <SummaryLine>{`${all.length} Einsätze`}</SummaryLine>
      <section className="px-8 md:px-16 py-16 md:py-20 max-w-5xl">
        {groups.filter((g) => g.items.length > 0).map((g) => (
          <div key={g.label} className="mb-14 last:mb-0">
            <GroupLabel>{g.label}</GroupLabel>
            <ul className="border-y border-border divide-y divide-border">
              {g.items.map((m: any) => (
                <li key={m.id}>
                  <ListRow
                    primary={
                      <>
                        <p className="font-serif text-xl text-navy">{m.talent_name}</p>
                        <p className="text-sm text-mid mt-1">{m.city}</p>
                      </>
                    }
                    meta={<MissionKernel kernel={m.kernel} view="greeter" subjectName={m.talent_name} size="row" />}
                    trailing={blockerTrailing(m.kernel) ?? labelStatus(m.status)}
                  />
                </li>
              ))}
            </ul>
          </div>
        ))}
        {all.length === 0 && <p className="text-mid italic">Noch nichts unterwegs.</p>}
      </section>
    </>
  );
}

function GreeterProfile() {
  const fn = useServerFn(getGreeterOverview);
  const { data } = useQuery({ queryKey: ["greeter-overview"], queryFn: () => fn() });
  const g = data?.greeter;
  return (
    <>
      <PortalHeader eyebrow="Profil" title="So begegnest du anderen." />
      <section className="px-8 md:px-16 py-16 md:py-20 max-w-2xl space-y-12">
        <div className="border-y border-border">
          <MetaRow label="Stadt" value={g?.city ?? "—"} />
          <MetaRow label="Sprachen" value={(g?.languages ?? []).join(" · ") || "—"} />
          <MetaRow label="Verfügbarkeit" value={g?.available ? "verfügbar" : "pausiert"} />
        </div>
        <div>
          <GroupLabel>Über dich</GroupLabel>
          <p className="font-serif text-xl text-navy leading-[1.6]">{g?.bio ?? "—"}</p>
        </div>
      </section>
    </>
  );
}

// =================== COMPANY ===================
function CompanyPortal({ fullName }: { fullName: string | null }) {
  const [selected, setSelected] = useState<string | null>(null);
  const fn = useServerFn(getCompanyOverview);
  const { data } = useQuery({ queryKey: ["company-overview"], queryFn: () => fn() });

  if (!data) {
    return (
      <PortalShell sectionLabel="Unternehmen" fullName={fullName} nav={[]}>
        <Empty>Einen Moment …</Empty>
      </PortalShell>
    );
  }

  const mission = selected ? (data.missions as any[]).find((m) => m.id === selected) : null;
  const missions = data.missions as any[];
  const counts = data.statusCounts as Record<string, number>;
  const groups = [
    { label: "Laufend", items: missions.filter((m) => m.status === "in_progress") },
    { label: "Bestätigt", items: missions.filter((m) => m.status === "confirmed" || m.status === "draft") },
    { label: "Abgeschlossen", items: missions.filter((m) => m.status === "completed" || m.status === "cancelled") },
  ];

  return (
    <PortalShell sectionLabel="Unternehmen" fullName={fullName} nav={[]}>
      <div key={mission ? mission.id : "overview"} className="nl-quiet">
        {mission ? (
          <MissionDetail mission={mission} onBack={() => setSelected(null)} />
        ) : (
          <>
            <PortalHeader
              eyebrow={data.company?.name ?? "Unternehmen"}
              title="Eure Einsätze."
              sub="Wer kommt, wer begleitet, wo. Mehr braucht es selten."
            />
            <SummaryLine>
              {`${missions.length} Einsätze${(data as any).lastUpdateAt ? ` · zuletzt aktualisiert ${formatRelative((data as any).lastUpdateAt)}` : ""}`}
            </SummaryLine>
            <section className="px-8 md:px-16 py-16 md:py-20 max-w-5xl">
              {groups.filter((g) => g.items.length > 0).map((g) => (
                <div key={g.label} className="mb-14 last:mb-0">
                  <GroupLabel>{g.label}</GroupLabel>
                  <ul className="border-y border-border divide-y divide-border">
                    {g.items.map((m: any) => (
                      <li key={m.id}>
                        <ListRow
                          onClick={() => setSelected(m.id)}
                          primary={
                            <>
                              <p className="font-serif text-xl text-navy">{m.talent_name}</p>
                              <p className="text-sm text-mid mt-1">{m.city}{m.greeter_name ? ` · mit ${m.greeter_name}` : ""}</p>
                            </>
                          }
                    meta={<MissionKernel kernel={m.kernel} view="ops" subjectName={m.talent_name} size="row" />}
                          trailing={blockerTrailing(m.kernel) ?? labelStatus(m.status)}
                        />
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
              {missions.length === 0 && <p className="text-mid italic">Noch ist es ruhig.</p>}
            </section>
          </>
        )}
      </div>
    </PortalShell>
  );
}

function MissionDetail({ mission, onBack }: { mission: any; onBack: () => void }) {
  const events = (mission.events ?? []) as any[];
  return (
    <>
      <PortalHeader
        eyebrow={`${mission.city} · ${labelStatus(mission.status)}`}
        title={mission.talent_name}
        sub={mission.summary ?? undefined}
      />
      {mission.kernel && (
        <section className="px-8 md:px-16 pt-16 md:pt-20 max-w-3xl">
          <MissionKernel
            kernel={mission.kernel}
            view="ops"
            subjectName={mission.talent_name}
            size="lg"
            context={[mission.city, mission.greeter_name ? `Begleitung ${mission.greeter_name}` : null].filter(Boolean).join(" · ")}
          />
        </section>
      )}
      <section className="px-8 md:px-16 py-16 md:py-20 grid grid-cols-1 md:grid-cols-[2fr_1fr] gap-16 max-w-6xl">
        <div>
          <GroupLabel>Verlauf</GroupLabel>
          {events.length === 0 ? (
            <p className="text-mid italic">Noch keine Einträge.</p>
          ) : (
            <ol className="space-y-10">
              {events.map((e) => (
                <li key={e.id} className="grid grid-cols-[5rem_1fr] gap-8">
                  <span className="font-serif italic text-gold text-base pt-1">{formatRelative(e.created_at)}</span>
                  <div>
                    <h3 className="font-serif text-lg text-navy leading-snug">{e.title}</h3>
                  </div>
                </li>
              ))}
            </ol>
          )}
        </div>
        <div>
          <GroupLabel>Eckdaten</GroupLabel>
          <div className="border-y border-border">
            <MetaRow label="Zeitraum" value={`${mission.starts_at ?? "—"} → ${mission.ends_at ?? "—"}`} />
            <MetaRow label="Begleitung" value={mission.greeter_name ?? "Noch offen"} />
            <MetaRow label="Stadt" value={mission.city} />
            <MetaRow label="Status" value={labelStatus(mission.status)} />
          </div>
          <button onClick={onBack} className="mt-12 text-sm border-b border-navy pb-1 text-navy hover:text-gold hover:border-gold transition-colors duration-500">
            Zurück
          </button>
        </div>
      </section>
    </>
  );
}

// =================== ADMIN ===================
function AdminPortal({ fullName }: { fullName: string | null }) {
  const [tab, setTab] = useState<"missions" | "companies" | "greeters">("missions");
  const fn = useServerFn(getAdminOverview);
  const { data } = useQuery({ queryKey: ["admin-overview"], queryFn: () => fn() });

  return (
    <PortalShell sectionLabel="Admin" fullName={fullName} nav={[]}>
      <InlineNav
        items={[
          { id: "missions", label: "Einsätze" },
          { id: "companies", label: "Unternehmen" },
          { id: "greeters", label: "Greeter" },
        ]}
        active={tab}
        onChange={(v) => setTab(v as any)}
      />
      <div key={tab} className="nl-quiet">
        {!data && <Empty>Einen Moment …</Empty>}
        {data && tab === "missions" && <AdminMissions missions={data.missions as any[]} counts={data.statusCounts} lastUpdateAt={(data as any).lastUpdateAt ?? null} />}
        {data && tab === "companies" && <AdminCompanies companies={data.companies as any[]} lastUpdateAt={(data as any).lastUpdateAt ?? null} />}
        {data && tab === "greeters" && <AdminGreeters greeters={data.greeters as any[]} lastUpdateAt={(data as any).lastUpdateAt ?? null} />}
      </div>
    </PortalShell>
  );
}

function AdminMissions({ missions, counts, lastUpdateAt }: { missions: any[]; counts: Record<string, number>; lastUpdateAt: string | null }) {
  const groups = [
    { label: "Laufend", items: missions.filter((m) => m.status === "in_progress") },
    { label: "Bestätigt", items: missions.filter((m) => m.status === "confirmed" || m.status === "draft") },
    { label: "Abgeschlossen", items: missions.filter((m) => m.status === "completed" || m.status === "cancelled") },
  ];
  return (
    <>
      <PortalHeader eyebrow="Einsätze" title="Was gerade läuft." />
      <SummaryLine>
        {`${missions.length} Einsätze${lastUpdateAt ? ` · zuletzt aktualisiert ${formatRelative(lastUpdateAt)}` : ""}`}
      </SummaryLine>
      <section className="px-8 md:px-16 py-16 md:py-20 max-w-5xl">
        {groups.filter((g) => g.items.length > 0).map((g) => (
          <div key={g.label} className="mb-14 last:mb-0">
            <GroupLabel>{g.label}</GroupLabel>
            <ul className="border-y border-border divide-y divide-border">
              {g.items.map((m: any) => (
                <li key={m.id}>
                  <ListRow
                    primary={
                      <>
                        <p className="font-serif text-xl text-navy">{m.talent_name}</p>
                        <p className="text-sm text-mid mt-1">
                          {m.company_name ?? "—"} · {m.city}{m.greeter_name ? ` · ${m.greeter_name}` : ""}
                        </p>
                      </>
                    }
                    meta={<MissionKernel kernel={m.kernel} view="ops" subjectName={m.talent_name} size="row" />}
                    trailing={blockerTrailing(m.kernel) ?? labelStatus(m.status)}
                  />
                </li>
              ))}
            </ul>
          </div>
        ))}
        {missions.length === 0 && <p className="text-mid italic">Gerade nichts unterwegs.</p>}
      </section>
    </>
  );
}

function AdminCompanies({ companies, lastUpdateAt }: { companies: any[]; lastUpdateAt: string | null }) {
  const total = companies.reduce((a, c) => a + (c.mission_count ?? 0), 0);
  return (
    <>
      <PortalHeader eyebrow="Unternehmen" title="Wer mit uns arbeitet." />
      <SummaryLine>{`${companies.length} Unternehmen · ${total} Einsätze insgesamt${lastUpdateAt ? ` · zuletzt ${formatRelative(lastUpdateAt)}` : ""}`}</SummaryLine>
      <section className="px-8 md:px-16 py-16 md:py-20 max-w-5xl">
        <ul className="border-y border-border divide-y divide-border">
          {companies.map((c) => (
            <li key={c.id}>
              <ListRow
                primary={<span className="font-serif text-xl text-navy">{c.name}</span>}
                meta={c.city ?? "—"}
                trailing={`${c.mission_count} ${c.mission_count === 1 ? "Einsatz" : "Einsätze"}`}
              />
            </li>
          ))}
          {companies.length === 0 && <li className="py-14 text-mid italic">Noch keine Unternehmen.</li>}
        </ul>
      </section>
    </>
  );
}

function AdminGreeters({ greeters, lastUpdateAt }: { greeters: any[]; lastUpdateAt: string | null }) {
  const available = greeters.filter((g) => g.available).length;
  const active = greeters.filter((g) => g.active_talent_name).length;
  return (
    <>
      <PortalHeader eyebrow="Greeter" title="Wer begleitet." />
      <SummaryLine>{`${greeters.length} Greeter · ${available} verfügbar · ${active} aktuell im Einsatz${lastUpdateAt ? ` · zuletzt ${formatRelative(lastUpdateAt)}` : ""}`}</SummaryLine>
      <section className="px-8 md:px-16 py-16 md:py-20 max-w-5xl">
        <ul className="border-y border-border divide-y divide-border">
          {greeters.map((g) => (
            <li key={g.user_id}>
              <ListRow
                primary={
                  <>
                    <p className="font-serif text-xl text-navy">{g.full_name}</p>
                    <p className="text-sm text-mid mt-1">{g.city} · {(g.languages ?? []).join(" · ")}</p>
                  </>
                }
                meta={
                  g.active_talent_name
                    ? (g.active_kernel
                        ? <MissionKernel kernel={g.active_kernel} view="ops" subjectName={g.active_talent_name} size="row" />
                        : <>begleitet {g.active_talent_name} in {g.active_city}</>)
                    : <span className="italic">frei</span>
                }
                trailing={g.available ? "verfügbar" : "pausiert"}
              />
            </li>
          ))}
          {greeters.length === 0 && <li className="py-14 text-mid italic">Noch keine Greeter.</li>}
        </ul>
      </section>
    </>
  );
}

// =================== PLACEHOLDER ===================
function PlaceholderPortal({ role, fullName }: { role: string; fullName: string | null }) {
  return (
    <PortalShell sectionLabel={role === "admin" ? "Admin" : "Unternehmen"} fullName={fullName} nav={[]}>
      <PortalHeader
        eyebrow={role === "admin" ? "Admin" : "Unternehmen"}
        title="Bald hier."
        sub="Diese Ansicht entsteht in der nächsten Phase."
      />
      <section className="px-8 md:px-16 py-16">
        <Link to="/" className="text-sm border-b border-navy pb-1 text-navy hover:text-gold hover:border-gold transition-colors">
          Zur Startseite
        </Link>
      </section>
    </PortalShell>
  );
}

// =================== helpers ===================
function InlineNav({ items, active, onChange }: { items: { id: string; label: string }[]; active: string; onChange: (id: string) => void }) {
  return (
    <nav className="px-8 md:px-16 pt-10 flex gap-10 border-b border-border">
      {items.map((i) => (
        <button
          key={i.id}
          onClick={() => onChange(i.id)}
          className={[
            "pb-5 text-sm -mb-px border-b transition-all duration-500",
            active === i.id ? "text-navy border-gold" : "text-mid border-transparent hover:text-navy",
          ].join(" ")}
        >
          {i.label}
        </button>
      ))}
    </nav>
  );
}

function Empty({ children }: { children: React.ReactNode }) {
  return <div className="px-8 md:px-16 py-32 text-mid italic">{children}</div>;
}

function labelStatus(s: string) {
  return ({
    draft: "Entwurf",
    confirmed: "bestätigt",
    in_progress: "läuft",
    completed: "abgeschlossen",
    cancelled: "abgebrochen",
  } as Record<string, string>)[s] ?? s;
}


function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("de-DE", { day: "2-digit", month: "short" });
}

function monogram(name: string | null | undefined): string {
  if (!name) return "·";
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "·";
  if (parts.length === 1) return parts[0].slice(0, 1).toUpperCase();
  return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
}
