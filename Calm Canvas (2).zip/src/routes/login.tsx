import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";

const searchSchema = z.object({ redirect: z.string().optional() });

export const Route = createFileRoute("/login")({
  validateSearch: (s) => searchSchema.parse(s),
  head: () => ({ meta: [{ title: "Anmelden — NeuLand" }] }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const { redirect } = Route.useSearch();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setBusy(true);
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setBusy(false);
    if (error) {
      setError("Die Kombination passt nicht. Versuch es noch einmal.");
      return;
    }
    navigate({ to: redirect ?? "/portal" });
  };

  return (
    <section className="min-h-[80vh] flex items-center">
      <div className="mx-auto max-w-[1180px] px-6 md:px-10 py-20 w-full grid md:grid-cols-2 gap-20 items-center">
        <div>
          <p className="nl-rise text-[11px] uppercase tracking-[0.28em] text-mid mb-10">Portal</p>
          <h1 className="nl-rise-2 font-serif text-[clamp(40px,5.2vw,68px)] leading-[1.05] text-navy">
            Willkommen <em className="text-gold">zurück.</em>
          </h1>
          <p className="nl-rise-3 mt-10 text-mid leading-relaxed max-w-md">
            Noch kein Konto?{" "}
            <Link to="/signup" className="text-navy border-b border-navy hover:text-gold hover:border-gold transition-colors">
              Hier anlegen
            </Link>
            .
          </p>
        </div>

        <form onSubmit={onSubmit} className="nl-rise-4 space-y-6 md:pt-8">
          <div className="space-y-2">
            <label className="text-[11px] uppercase tracking-[0.28em] text-mid">E-Mail</label>
            <input
              type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-transparent border-b border-navy/30 focus:border-gold outline-none py-3 text-navy text-lg transition-colors"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[11px] uppercase tracking-[0.28em] text-mid">Passwort</label>
            <input
              type="password" required value={password} onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-transparent border-b border-navy/30 focus:border-gold outline-none py-3 text-navy text-lg transition-colors"
            />
          </div>
          {error && <p className="text-sm text-mid italic">{error}</p>}
          <button
            type="submit" disabled={busy}
            className="inline-flex items-center gap-3 text-navy disabled:opacity-50 pt-2"
          >
            <span className="border-b border-navy pb-1 hover:border-gold hover:text-gold transition-colors">
              {busy ? "Einen Moment …" : "Anmelden"}
            </span>
            <span className="transition-transform group-hover:translate-x-1">→</span>
          </button>
          <div className="pt-10 border-t border-border">
            <button
              type="button"
              onClick={async () => {
                const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/portal" });
                if (r.error) setError("Mit Google hat es gerade nicht geklappt.");
              }}
              className="text-sm text-mid hover:text-navy transition-colors block"
            >
              Mit Google fortfahren  →
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}
