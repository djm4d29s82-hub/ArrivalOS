import { createFileRoute, useNavigate, redirect } from "@tanstack/react-router";
import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { supabase } from "@/integrations/supabase/client";
import { seedDemoAndGetCredentials, type DemoRole } from "@/lib/demo.functions";
import { getMyRoles } from "@/lib/portal.functions";

export const Route = createFileRoute("/demo")({
  // Demo is a development mode, not a feature. Gate it.
  beforeLoad: async () => {
    if (import.meta.env.DEV) return;
    const { data, error } = await supabase.auth.getUser();
    if (error || !data.user) throw redirect({ to: "/login", search: { redirect: "/demo" } });
    try {
      const roles = await getMyRoles();
      if (!roles.roles.includes("admin")) throw redirect({ to: "/" });
    } catch {
      throw redirect({ to: "/" });
    }
  },
  head: () => ({ meta: [{ title: "Demo — NeuLand" }] }),
  component: DemoPage,
});

const roles: { id: DemoRole; label: string; sub: string }[] = [
  { id: "talent", label: "Talent", sub: "Eine Person, die ankommt." },
  { id: "greeter", label: "Greeter", sub: "Jemand, der sie begleitet." },
  { id: "company", label: "Unternehmen", sub: "Das HR-Team dahinter." },
  { id: "admin", label: "Admin", sub: "Die Sicht von NeuLand selbst." },
];

function DemoPage() {
  const navigate = useNavigate();
  const seed = useServerFn(seedDemoAndGetCredentials);
  const [loading, setLoading] = useState<DemoRole | null>(null);
  const [error, setError] = useState<string | null>(null);

  const pick = async (role: DemoRole) => {
    setError(null);
    setLoading(role);
    try {
      const { email, password } = await seed({ data: { role } });
      await supabase.auth.signOut();
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      navigate({ to: "/portal" });
    } catch {
      setError("Die Demo lässt sich gerade nicht öffnen. Versuch es in einem Moment noch einmal.");
      setLoading(null);
    }
  };

  return (
    <section className="min-h-[80vh]">
      <div className="mx-auto max-w-[1180px] px-6 md:px-10 py-28 md:py-40">
        <p className="nl-rise text-[11px] uppercase tracking-[0.28em] text-mid mb-12">
          Demo · Entwicklungsmodus
        </p>
        <h1 className="nl-rise-2 font-serif text-[clamp(36px,5vw,64px)] leading-[1.05] text-navy max-w-[20ch]">
          Aus welcher Perspektive möchtest du <em className="text-gold">eintreten?</em>
        </h1>
        <p className="nl-rise-3 mt-10 max-w-xl text-mid leading-relaxed">
          Diese Ansicht ist nur für interne Tests. Echte Konten werden über den normalen Login angelegt.
        </p>

        <div className="mt-20 grid sm:grid-cols-2 gap-px bg-border border border-border">
          {roles.map((r) => (
            <button
              key={r.id}
              onClick={() => pick(r.id)}
              disabled={loading !== null}
              className="group text-left bg-cream p-12 md:p-16 hover:bg-cream-2 transition-colors duration-500 disabled:opacity-50 disabled:cursor-wait"
            >
              <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-8">
                {loading === r.id ? "Einen Moment …" : "Eintreten als"}
              </p>
              <h3 className="font-serif text-3xl text-navy group-hover:text-gold transition-colors duration-500">{r.label}</h3>
              <p className="mt-4 text-mid">{r.sub}</p>
            </button>
          ))}
        </div>

        {error && <p className="mt-10 text-sm text-mid italic">{error}</p>}
      </div>
    </section>
  );
}
