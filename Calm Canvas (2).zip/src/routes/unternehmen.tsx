import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/unternehmen")({
  head: () => ({
    meta: [
      { title: "Für Unternehmen — NeuLand" },
      { name: "description", content: "NeuLand übernimmt die menschliche Seite der Relocation. Damit Ihre internationalen Fachkräfte ankommen — und bleiben." },
      { property: "og:title", content: "Für Unternehmen — NeuLand" },
      { property: "og:description", content: "Damit Ihre Fachkräfte ankommen, nicht nur umziehen." },
    ],
  }),
  component: Unternehmen,
});

function Unternehmen() {
  return (
    <>
      <section className="min-h-[72vh] flex items-center">
        <div className="mx-auto max-w-[1180px] px-6 md:px-10 py-24 md:py-32 w-full">
          <p className="nl-rise text-[11px] uppercase tracking-[0.28em] text-mid mb-10">Für Unternehmen</p>
          <h1 className="nl-rise-2 font-serif text-[clamp(40px,5.6vw,80px)] leading-[1.05] text-navy max-w-[16ch]">
            Talente, die <em className="text-gold">bleiben.</em>
          </h1>
          <p className="nl-rise-3 mt-10 max-w-xl text-lg text-mid leading-relaxed">
            Sie investieren Monate in Recruiting. Wir sorgen dafür, dass die ersten Wochen
            danach kein Zufall sind — sondern eine echte Ankunft.
          </p>
        </div>
      </section>

      <section className="border-t border-border">
        <div className="mx-auto max-w-[980px] px-6 md:px-10 py-32">
          <p className="text-[11px] uppercase tracking-[0.28em] text-gold mb-10">Wie wir arbeiten</p>
          <p className="font-serif text-[clamp(26px,3.2vw,42px)] leading-[1.3] text-navy">
            Ein lokaler Greeter empfängt Ihre neuen Mitarbeiter:innen am ersten Tag,
            zeigt ihnen das Viertel, begleitet sie zu Behördengängen, beantwortet die kleinen Fragen,
            die man nicht googeln kann. <span className="text-mid">Sechs Wochen lang. Persönlich. Konstant.</span>
          </p>
        </div>
      </section>

      <section className="border-t border-border bg-cream-2">
        <div className="mx-auto max-w-[1180px] px-6 md:px-10 py-32 md:py-40 text-center">
          <h2 className="font-serif text-[clamp(32px,4.4vw,60px)] leading-tight text-navy max-w-[20ch] mx-auto">
            Sprechen wir über Ihren nächsten Standort.
          </h2>
          <Link
            to="/kontakt"
            className="mt-12 inline-flex items-center gap-3 text-navy"
          >
            <span className="border-b border-navy pb-1 hover:border-gold hover:text-gold transition-colors">
              Gespräch anfragen
            </span>
            <span>→</span>
          </Link>
        </div>
      </section>
    </>
  );
}
