import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";

export const Route = createFileRoute("/signup")({
  head: () => ({ meta: [{ title: "Konto anlegen — NeuLand" }] }),
  component: SignupPage,
});

function SignupPage() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const [busy, setBusy] = useState(false);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setBusy(true);
    const { data, error } = await supabase.auth.signUp({
      email,
      password,
      options: {
        emailRedirectTo: `${window.location.origin}/portal`,
        data: { full_name: fullName },
      },
    });
    setBusy(false);
    if (error) {
      setError("Das hat nicht geklappt. Vielleicht existiert das Konto schon.");
      return;
    }
    if (data.session) {
      navigate({ to: "/portal" });
    } else {
      setDone(true);
    }
  };

  return (
    <section className="min-h-[80vh] flex items-center">
      <div className="mx-auto max-w-[1180px] px-6 md:px-10 py-20 w-full grid md:grid-cols-2 gap-20 items-center">
        <div>
          <p className="nl-rise text-[11px] uppercase tracking-[0.28em] text-mid mb-10">Konto anlegen</p>
          <h1 className="nl-rise-2 font-serif text-[clamp(40px,5.2vw,68px)] leading-[1.05] text-navy">
            Lass uns <em className="text-gold">beginnen.</em>
          </h1>
          <p className="nl-rise-3 mt-10 text-mid leading-relaxed max-w-md">
            Dein Konto ist der erste Schritt. Greeter, Unternehmen und Admins werden direkt von uns eingerichtet.
          </p>
          <p className="nl-rise-3 mt-6 text-mid text-sm">
            Schon dabei?{" "}
            <Link to="/login" className="text-navy border-b border-navy hover:text-gold hover:border-gold transition-colors">
              Hier anmelden
            </Link>
          </p>
        </div>

        {done ? (
          <div className="nl-rise-4 md:pt-8 space-y-6">
            <p className="text-[11px] uppercase tracking-[0.28em] text-mid">Fast geschafft</p>
            <p className="font-serif text-2xl text-navy leading-snug">
              Wir haben dir eine E-Mail geschickt. Bestätige deine Adresse, dann geht es weiter.
            </p>
          </div>
        ) : (
          <form onSubmit={onSubmit} className="nl-rise-4 space-y-6 md:pt-8">
            <div className="space-y-2">
              <label className="text-[11px] uppercase tracking-[0.28em] text-mid">Name</label>
              <input
                type="text" required value={fullName} onChange={(e) => setFullName(e.target.value)}
                className="w-full bg-transparent border-b border-navy/30 focus:border-gold outline-none py-3 text-navy text-lg transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[11px] uppercase tracking-[0.28em] text-mid">E-Mail</label>
              <input
                type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-transparent border-b border-navy/30 focus:border-gold outline-none py-3 text-navy text-lg transition-colors"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[11px] uppercase tracking-[0.28em] text-mid">Passwort</label>
              <input
                type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-transparent border-b border-navy/30 focus:border-gold outline-none py-3 text-navy text-lg transition-colors"
              />
            </div>
            {error && <p className="text-sm text-mid italic">{error}</p>}
            <button
              type="submit" disabled={busy}
              className="inline-flex items-center gap-3 text-navy disabled:opacity-50 pt-2"
            >
              <span className="border-b border-navy pb-1 hover:border-gold hover:text-gold transition-colors">
                {busy ? "Einen Moment …" : "Konto anlegen"}
              </span>
              <span>→</span>
            </button>
            <div className="pt-10 border-t border-border">
              <button
                type="button"
                onClick={async () => {
                  const r = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin + "/portal" });
                  if (r.error) setError("Mit Google hat es gerade nicht geklappt.");
                }}
                className="text-sm text-mid hover:text-navy transition-colors block"
              >
                Mit Google fortfahren  →
              </button>
            </div>
          </form>
        )}
      </div>
    </section>
  );
}
