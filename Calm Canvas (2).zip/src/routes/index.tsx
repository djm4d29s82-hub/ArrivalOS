import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "NeuLand — Ankunft, menschlich gemacht." },
      { name: "description", content: "NeuLand verbindet internationale Talente mit lokalen Greetern. Eine ruhige Ankunft, von Anfang an." },
      { property: "og:title", content: "NeuLand — Ankunft, menschlich gemacht." },
      { property: "og:description", content: "Eine ruhige Ankunft, von Anfang an." },
    ],
  }),
  component: Home,
});

function Home() {
  return (
    <>
      {/* HERO */}
      <section className="relative min-h-[92vh] flex items-center">
        <div className="mx-auto max-w-[1180px] px-6 md:px-10 py-24 md:py-32 w-full">
          <p className="nl-rise text-[11px] uppercase tracking-[0.28em] text-mid mb-10">
            <span className="inline-block w-1.5 h-1.5 rounded-full bg-gold mr-3 align-middle" />
            Human Arrival · Made in Germany
          </p>
          <h1 className="nl-rise-2 font-serif text-[clamp(48px,7vw,104px)] leading-[1.02] text-navy max-w-[18ch]">
            Ankunft,<br />
            <em className="text-gold">menschlich</em> gemacht.
          </h1>
          <p className="nl-rise-3 mt-10 max-w-xl text-lg text-mid leading-relaxed">
            NeuLand begleitet internationale Talente in den ersten Wochen in einer neuen Stadt —
            mit echten Menschen vor Ort, nicht mit einer App, die sie alleine lässt.
          </p>
          <div className="nl-rise-4 mt-12 flex items-center gap-8">
            <Link
              to="/unternehmen"
              className="group inline-flex items-center gap-3 text-navy text-sm"
            >
              <span className="border-b border-navy pb-1 group-hover:border-gold group-hover:text-gold transition-colors">
                Für Unternehmen
              </span>
              <span className="group-hover:translate-x-1 transition-transform">→</span>
            </Link>
            <Link
              to="/greeter"
              className="text-sm text-mid hover:text-navy transition-colors"
            >
              Greeter werden
            </Link>
          </div>
        </div>
      </section>

      {/* MANIFESTO */}
      <section className="border-t border-border">
        <div className="mx-auto max-w-[980px] px-6 md:px-10 py-32 md:py-44">
          <p className="text-[11px] uppercase tracking-[0.28em] text-gold mb-10">Was wir glauben</p>
          <p className="font-serif text-[clamp(28px,3.6vw,48px)] leading-[1.25] text-navy">
            Niemand sollte in einer neuen Stadt ankommen und sich verloren fühlen.
            <span className="text-mid"> Eine gute Ankunft ist kein Onboarding-Ticket. Sie ist ein Mensch,
            der die Tür öffnet — und sagt: schön, dass du da bist.</span>
          </p>
        </div>
      </section>

      {/* TWO PATHS */}
      <section className="border-t border-border">
        <div className="mx-auto max-w-[1180px] px-6 md:px-10 py-32 grid md:grid-cols-2 gap-20">
          <Link to="/unternehmen" className="group block">
            <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-6">Für Unternehmen</p>
            <h3 className="font-serif text-4xl text-navy group-hover:text-gold transition-colors">
              Talente, die bleiben.
            </h3>
            <p className="mt-4 text-mid leading-relaxed max-w-md">
              Wir kümmern uns um die menschliche Seite der Relocation —
              damit Ihre Fachkräfte ankommen, nicht nur umziehen.
            </p>
            <span className="mt-6 inline-block text-sm text-navy border-b border-navy pb-1 group-hover:text-gold group-hover:border-gold transition-colors">
              Mehr erfahren →
            </span>
          </Link>
          <Link to="/greeter" className="group block">
            <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-6">Für Greeter</p>
            <h3 className="font-serif text-4xl text-navy group-hover:text-gold transition-colors">
              Sei das erste Gesicht.
            </h3>
            <p className="mt-4 text-mid leading-relaxed max-w-md">
              Werde Teil einer Bewegung, die echten Unterschied macht —
              in deiner Stadt, in deiner Zeit, in deinem Rhythmus.
            </p>
            <span className="mt-6 inline-block text-sm text-navy border-b border-navy pb-1 group-hover:text-gold group-hover:border-gold transition-colors">
              Mitmachen →
            </span>
          </Link>
        </div>
      </section>
    </>
  );
}
