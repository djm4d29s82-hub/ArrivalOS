import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/ueber-uns")({
  head: () => ({
    meta: [
      { title: "Über uns — NeuLand" },
      { name: "description", content: "Internationale Fachkräfte sollen sich nach ihrer Ankunft in Deutschland nicht verloren fühlen. Daran arbeiten wir." },
      { property: "og:title", content: "Über uns — NeuLand" },
      { property: "og:description", content: "Warum es NeuLand gibt." },
    ],
  }),
  component: Ueber,
});

function Ueber() {
  return (
    <>
      <section className="bg-navy-3 text-cream">
        <div className="mx-auto max-w-[1180px] px-6 md:px-10 py-32 md:py-48">
          <p className="nl-rise text-[11px] uppercase tracking-[0.28em] text-gold mb-10">Über uns</p>
          <h1 className="nl-rise-2 font-serif text-[clamp(36px,4.8vw,72px)] leading-[1.15] text-cream max-w-[24ch]">
            Internationale Fachkräfte sollen sich nach ihrer Ankunft in Deutschland
            <em className="text-gold"> nicht verloren</em> fühlen.
          </h1>
        </div>
      </section>

      <section>
        <div className="mx-auto max-w-[760px] px-6 md:px-10 py-32 space-y-10 text-lg text-mid leading-relaxed">
          <p>
            NeuLand ist aus einer einfachen Beobachtung entstanden: Unternehmen geben enorme Mühe
            darauf, internationale Talente zu finden — und überlassen sie nach der Vertragsunterschrift
            sich selbst.
          </p>
          <p>
            Der erste Monat in einem fremden Land entscheidet darüber, ob jemand bleibt.
            Nicht das Gehalt. Nicht der Tisch im Büro. Sondern das Gefühl, willkommen zu sein.
          </p>
          <p className="font-serif text-2xl text-navy not-italic">
            Wir bauen Infrastruktur für genau dieses Gefühl.
          </p>
        </div>
      </section>
    </>
  );
}
