import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/kontakt")({
  head: () => ({
    meta: [
      { title: "Kontakt — NeuLand" },
      { name: "description", content: "Schreiben Sie uns. Wir antworten persönlich." },
      { property: "og:title", content: "Kontakt — NeuLand" },
      { property: "og:description", content: "Schreiben Sie uns. Wir antworten persönlich." },
    ],
  }),
  component: Kontakt,
});

function Kontakt() {
  return (
    <section className="min-h-[80vh] flex items-center">
      <div className="mx-auto max-w-[1180px] px-6 md:px-10 py-32 w-full grid md:grid-cols-2 gap-20 items-start">
        <div>
          <p className="nl-rise text-[11px] uppercase tracking-[0.28em] text-mid mb-10">Kontakt</p>
          <h1 className="nl-rise-2 font-serif text-[clamp(40px,5.4vw,76px)] leading-[1.05] text-navy">
            Schreiben Sie <em className="text-gold">uns.</em>
          </h1>
          <p className="nl-rise-3 mt-10 text-lg text-mid leading-relaxed max-w-md">
            Eine Mail genügt. Wir antworten persönlich, meist innerhalb von 24 Stunden.
          </p>
        </div>

        <div className="nl-rise-4 space-y-10 md:pt-16">
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-3">E-Mail</p>
            <a
              href="mailto:hallo@neuland.de"
              className="font-serif text-3xl text-navy border-b border-navy pb-1 hover:text-gold hover:border-gold transition-colors"
            >
              hallo@neuland.de
            </a>
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-3">Sitz</p>
            <p className="text-navy">Berlin, Deutschland</p>
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-3">Presse</p>
            <a
              href="mailto:presse@neuland.de"
              className="text-navy hover:text-gold transition-colors"
            >
              presse@neuland.de
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
