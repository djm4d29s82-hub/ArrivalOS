import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import {
  Outlet,
  Link,
  createRootRouteWithContext,
  useRouter,
  useRouterState,
  HeadContent,
  Scripts,
} from "@tanstack/react-router";

import appCss from "../styles.css?url";

function NotFoundComponent() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-cream px-4">
      <div className="max-w-md text-center">
        <p className="text-xs uppercase tracking-[0.2em] text-mid">404</p>
        <h1 className="mt-4 font-serif text-5xl text-navy">Hier ist nichts.</h1>
        <p className="mt-4 text-sm text-mid">Die Seite, die du suchst, existiert nicht — oder noch nicht.</p>
        <Link to="/" className="mt-8 inline-block border-b border-navy pb-1 text-sm text-navy hover:text-gold hover:border-gold transition-colors">
          Zurück zum Anfang
        </Link>
      </div>
    </div>
  );
}

function ErrorComponent({ error, reset }: { error: Error; reset: () => void }) {
  console.error(error);
  const router = useRouter();
  return (
    <div className="flex min-h-screen items-center justify-center bg-cream px-4">
      <div className="max-w-md text-center">
        <h1 className="font-serif text-3xl text-navy">Etwas ist schiefgelaufen.</h1>
        <p className="mt-3 text-sm text-mid">Versuche es noch einmal.</p>
        <button
          onClick={() => { router.invalidate(); reset(); }}
          className="mt-6 border-b border-navy pb-1 text-sm text-navy hover:text-gold hover:border-gold transition-colors"
        >
          Neu laden
        </button>
      </div>
    </div>
  );
}

export const Route = createRootRouteWithContext<{ queryClient: QueryClient }>()({
  head: () => ({
    meta: [
      { charSet: "utf-8" },
      { name: "viewport", content: "width=device-width, initial-scale=1" },
      { title: "NeuLand — Ankunft, menschlich gemacht." },
      { name: "description", content: "NeuLand verbindet internationale Talente mit lokalen Greetern. Eine ruhige Ankunft, von Anfang an." },
      { property: "og:title", content: "NeuLand — Ankunft, menschlich gemacht." },
      { property: "og:description", content: "NeuLand verbindet internationale Talente mit lokalen Greetern." },
      { property: "og:type", content: "website" },
    ],
    links: [
      { rel: "stylesheet", href: appCss },
      { rel: "preconnect", href: "https://fonts.googleapis.com" },
      { rel: "preconnect", href: "https://fonts.gstatic.com", crossOrigin: "anonymous" },
      {
        rel: "stylesheet",
        href: "https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,600;0,700;1,400&family=DM+Sans:opsz,wght@9..40,300;9..40,400;9..40,500&display=swap",
      },
    ],
  }),
  shellComponent: RootShell,
  component: RootComponent,
  notFoundComponent: NotFoundComponent,
  errorComponent: ErrorComponent,
});

function RootShell({ children }: { children: React.ReactNode }) {
  return (
    <html lang="de">
      <head><HeadContent /></head>
      <body>
        {children}
        <Scripts />
      </body>
    </html>
  );
}

const navItems = [
  { to: "/unternehmen", label: "Unternehmen" },
  { to: "/greeter", label: "Greeter werden" },
  { to: "/ueber-uns", label: "Über uns" },
  { to: "/kontakt", label: "Kontakt" },
] as const;

function SiteNav() {
  return (
    <header className="fixed top-0 inset-x-0 z-50 h-16 backdrop-blur-md bg-cream/85 border-b border-border">
      <div className="mx-auto h-full max-w-[1180px] px-6 md:px-10 flex items-center justify-between">
        <Link to="/" className="font-serif text-[19px] text-navy tracking-tight">
          Neu<em className="not-italic text-gold">Land</em>
        </Link>
        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((n) => (
            <Link
              key={n.to}
              to={n.to}
              className="text-[13px] text-mid hover:text-navy transition-colors"
              activeProps={{ className: "text-[13px] text-navy font-medium" }}
            >
              {n.label}
            </Link>
          ))}
          <Link to="/login" className="text-[13px] text-navy border-b border-navy pb-0.5 hover:text-gold hover:border-gold transition-colors">
            Anmelden
          </Link>
        </nav>
      </div>
    </header>
  );
}

function SiteFooter() {
  return (
    <footer className="border-t border-border mt-32">
      <div className="mx-auto max-w-[1180px] px-6 md:px-10 py-12 flex flex-col md:flex-row items-start md:items-end justify-between gap-8">
        <div>
          <div className="font-serif text-xl text-navy">Neu<em className="not-italic text-gold">Land</em></div>
          <p className="mt-2 text-xs text-light max-w-xs leading-relaxed">
            Ankunft, menschlich gemacht. Made in Germany.
          </p>
        </div>
        <nav className="flex flex-wrap gap-x-6 gap-y-2 text-xs text-mid">
          {navItems.map((n) => (
            <Link key={n.to} to={n.to} className="hover:text-navy transition-colors">{n.label}</Link>
          ))}
        </nav>
        <p className="text-xs text-light">© {new Date().getFullYear()} NeuLand</p>
      </div>
    </footer>
  );
}

function RootComponent() {
  const { queryClient } = Route.useRouteContext();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const isPortal = pathname.startsWith("/portal");
  return (
    <QueryClientProvider client={queryClient}>
      {isPortal ? (
        <Outlet />
      ) : (
        <div className="min-h-screen flex flex-col bg-cream">
          <SiteNav />
          <main className="flex-1 pt-16">
            <Outlet />
          </main>
          <SiteFooter />
        </div>
      )}
    </QueryClientProvider>
  );
}
