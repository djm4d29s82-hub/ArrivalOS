import { Link, useRouterState } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import type { ReactNode } from "react";
import { formatRelative } from "@/lib/relativeTime";
import type { MissionKernel as MissionKernelData } from "@/lib/missionKernel";
import { renderKernel, type ViewKey } from "@/lib/missionRenderer";

export type NavItem = { to: string; label: string };

export function PortalShell({
  sectionLabel,
  fullName,
  nav,
  children,
}: {
  sectionLabel: string;
  fullName: string | null;
  nav: NavItem[];
  children: ReactNode;
}) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  return (
    <div className="min-h-screen flex bg-cream">
      <aside className="hidden md:flex w-64 shrink-0 border-r border-border flex-col justify-between p-8 sticky top-0 h-screen">
        <div>
          <Link to="/" className="font-serif text-[19px] text-navy tracking-tight block mb-12">
            Neu<em className="not-italic text-gold">Land</em>
          </Link>
          <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-6">{sectionLabel}</p>
          <nav className="flex flex-col gap-1">
            {nav.map((n) => {
              const active = pathname === n.to || (n.to !== "/portal" && pathname.startsWith(n.to));
              return (
                <Link
                  key={n.to}
                  to={n.to}
                  className={[
                    "py-2 text-[15px] transition-colors",
                    active ? "text-navy" : "text-mid hover:text-navy",
                  ].join(" ")}
                >
                  {active && <span className="text-gold mr-2">·</span>}
                  {n.label}
                </Link>
              );
            })}
          </nav>
        </div>
        <div className="text-xs">
          {fullName && <p className="text-navy mb-2 font-serif text-base">{fullName}</p>}
          <button onClick={signOut} className="text-mid hover:text-navy transition-colors">
            Abmelden
          </button>
        </div>
      </aside>
      <main className="flex-1 min-w-0">{children}</main>
    </div>
  );
}

export function PortalHeader({ eyebrow, title, sub }: { eyebrow?: string; title: string; sub?: string }) {
  return (
    <header className="px-8 md:px-16 pt-20 md:pt-32 pb-16 border-b border-border">
      {eyebrow && (
        <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-8">{eyebrow}</p>
      )}
      <h1 className="font-serif text-[clamp(32px,4vw,56px)] leading-[1.08] text-navy max-w-[22ch]">
        {title}
      </h1>
      {sub && <p className="mt-8 text-mid max-w-xl leading-[1.75]">{sub}</p>}
    </header>
  );
}

export function SummaryLine({ children }: { children: ReactNode }) {
  return (
    <p className="px-8 md:px-16 pt-10 text-sm text-mid leading-relaxed">{children}</p>
  );
}

export function GroupLabel({ children, className = "" }: { children: ReactNode; className?: string }) {
  return (
    <p className={`text-[11px] uppercase tracking-[0.28em] text-mid mb-5 ${className}`}>{children}</p>
  );
}

export function MetaRow({ label, value }: { label: string; value: ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-8 py-4 border-b border-border last:border-0">
      <span className="text-[11px] uppercase tracking-[0.28em] text-mid shrink-0">{label}</span>
      <span className="font-serif text-lg text-navy text-right">{value}</span>
    </div>
  );
}

export function ListRow({
  primary,
  meta,
  trailing,
  onClick,
}: {
  primary: ReactNode;
  meta?: ReactNode;
  trailing?: ReactNode;
  onClick?: () => void;
}) {
  const Cmp: any = onClick ? "button" : "div";
  return (
    <Cmp
      onClick={onClick}
      className={[
        "w-full text-left grid grid-cols-[1.4fr_1.4fr_auto] gap-8 items-baseline py-7 md:py-8",
        onClick ? "group cursor-pointer" : "",
      ].join(" ")}
    >
      <div className={onClick ? "group-hover:text-gold transition-colors duration-500" : ""}>
        {primary}
      </div>
      <div className="text-sm text-mid leading-relaxed">{meta}</div>
      <div className="text-xs uppercase tracking-[0.2em] text-mid whitespace-nowrap pl-4">
        {trailing}
      </div>
    </Cmp>
  );
}

export function MissionKernel({
  kernel,
  view,
  subjectName,
  size = "lg",
  context,
}: {
  kernel: MissionKernelData | null | undefined;
  view: ViewKey;
  subjectName?: string;
  size?: "lg" | "row";
  context?: ReactNode;
}) {
  if (!kernel) return null;
  const sentences = renderKernel(kernel, view, subjectName);

  if (size === "row") {
    return (
      <>
        <span className="text-navy">{sentences.state}</span>
        {kernel.state.since && <span className="text-mid"> · {formatRelative(kernel.state.since)}</span>}
        {sentences.next && (
          <>
            <br />
            <span className="text-mid">als nächstes: </span>
            <span className="text-navy">{sentences.next}</span>
            {kernel.next?.when && <span className="text-mid"> · {formatRelative(kernel.next.when)}</span>}
          </>
        )}
      </>
    );
  }

  return (
    <div className="space-y-12">
      <div>
        <p className="text-[11px] uppercase tracking-[0.28em] text-mid">Gerade</p>
        <p className="font-serif text-2xl md:text-3xl text-navy mt-2 leading-snug">{sentences.state}</p>
        {kernel.state.since && <p className="text-mid text-sm mt-2">{formatRelative(kernel.state.since)}</p>}
        {context && <p className="text-mid text-sm mt-3 leading-relaxed">{context}</p>}
      </div>
      {sentences.next && (
        <div className="border-l border-gold pl-6">
          <p className="text-[11px] uppercase tracking-[0.28em] text-mid">Nächster Schritt</p>
          <p className="font-serif text-xl text-navy mt-2 leading-snug">{sentences.next}</p>
          {kernel.next?.when && <p className="text-mid text-sm mt-2">{formatRelative(kernel.next.when)}</p>}
        </div>
      )}
      {sentences.blockers.length > 0 && (
        <div>
          <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-3">Was fehlt</p>
          <ul className="space-y-2">
            {sentences.blockers.map((b, i) => (
              <li key={i} className="text-navy text-base">
                <span className="text-gold mr-3">·</span>{b}
              </li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export function blockerTrailing(kernel: MissionKernelData | null | undefined): string | null {
  if (!kernel || kernel.blockers.length === 0) return null;
  const n = kernel.blockers.reduce(
    (sum, b) => sum + (b.code === "plus_n_more" ? (b.count ?? 0) : 1),
    0,
  );
  return n === 1 ? "1 fehlt" : `${n} fehlen`;
}
