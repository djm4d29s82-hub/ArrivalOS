import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { postMissionEvent, setBlocker, resolveBlocker } from "@/lib/operations.functions";
import { nextGreeterTap, TAP_LABELS, eventToHumanLine } from "@/lib/eventTaxonomy";
import { formatRelative } from "@/lib/relativeTime";

type Props = { data: any | null };

function monogram(name: string | null) {
  if (!name) return "·";
  return name.split(" ").filter(Boolean).slice(0, 2).map((w) => w[0]?.toUpperCase()).join("");
}

function fmtTime(iso: string | null) {
  if (!iso) return null;
  const d = new Date(iso);
  return d.toLocaleString("de-DE", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "short" });
}

export function GreeterMissionCard({ data: initial }: Props) {
  const qc = useQueryClient();
  const post = useServerFn(postMissionEvent);
  const setBlk = useServerFn(setBlocker);
  const clearBlk = useServerFn(resolveBlocker);
  const [blockerOpen, setBlockerOpen] = useState(false);
  const [blockerText, setBlockerText] = useState("");

  // Realtime: invalidate-only
  useEffect(() => {
    if (!initial?.mission?.id) return;
    const id = initial.mission.id;
    const ch = supabase
      .channel(`greeter-mission-${id}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "mission_events", filter: `mission_id=eq.${id}` },
        () => qc.invalidateQueries({ queryKey: ["greeter-today"] }))
      .on("postgres_changes", { event: "*", schema: "public", table: "blockers", filter: `mission_id=eq.${id}` },
        () => qc.invalidateQueries({ queryKey: ["greeter-today"] }))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [initial?.mission?.id, qc]);

  const tap = useMutation({
    mutationFn: async (vars: { kind: string; title: string }) => {
      return post({ data: { missionId: initial!.mission.id, kind: vars.kind as any, title: vars.title } });
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["greeter-today"] }),
  });

  const reportBlocker = useMutation({
    mutationFn: async (reason: string) =>
      setBlk({ data: { missionId: initial!.mission.id, reason } }),
    onSuccess: () => {
      setBlockerOpen(false);
      setBlockerText("");
      qc.invalidateQueries({ queryKey: ["greeter-today"] });
    },
  });

  const resolve = useMutation({
    mutationFn: async (blockerId: string) => clearBlk({ data: { blockerId } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["greeter-today"] }),
  });

  if (!initial) {
    return <p className="text-mid italic text-sm px-8 md:px-16 py-16">Einen Moment …</p>;
  }

  if (!initial.mission) {
    const next = initial.next;
    return (
      <section className="px-8 md:px-16 py-20 max-w-2xl">
        <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-8">Heute</p>
        <h1 className="font-serif text-4xl text-navy leading-tight">Heute keine Ankunft.</h1>
        {next && (
          <p className="text-mid mt-8 leading-relaxed">
            Nächste: <span className="text-navy">{next.talent_name ?? "—"}</span>
            {next.scheduled_arrival ? ` · ${fmtTime(next.scheduled_arrival)}` : next.starts_at ? ` · ${next.starts_at}` : ""}
            {next.city ? ` · ${next.city}` : ""}.
          </p>
        )}
      </section>
    );
  }

  const m = initial.mission;
  const t = initial.talent;
  const tap_ = nextGreeterTap(initial.eventKinds);
  const tapMeta = TAP_LABELS[tap_];

  return (
    <section className="px-8 md:px-12 py-12 md:py-16 max-w-2xl">
      {/* HEAD: Wer · Wo · Wann */}
      <div className="flex items-start gap-6 mb-10">
        {t.photo_url ? (
          <img src={t.photo_url} alt={t.full_name ?? ""} className="h-24 w-24 object-cover shrink-0" />
        ) : (
          <div className="h-24 w-24 shrink-0 bg-navy text-cream font-serif text-3xl flex items-center justify-center">
            {monogram(t.full_name)}
          </div>
        )}
        <div className="pt-1 min-w-0">
          <h1 className="font-serif text-3xl md:text-4xl text-navy leading-tight">{t.full_name ?? "—"}</h1>
          <p className="text-mid text-sm mt-2">
            {[t.home_country, t.languages.length ? t.languages.join(" · ") : null].filter(Boolean).join(" · ") || "—"}
          </p>
        </div>
      </div>

      <div className="border-y border-border py-6 mb-10 space-y-2">
        <p className="font-serif text-xl text-navy">
          {[m.airline, m.flight_number].filter(Boolean).join(" ") || "Flug —"}
          {m.scheduled_arrival ? <span className="text-mid"> · ETA {fmtTime(m.scheduled_arrival)}</span> : null}
        </p>
        <p className="text-mid text-sm">
          {[m.arrival_airport, m.arrival_terminal ? `Terminal ${m.arrival_terminal}` : null, m.arrival_gate ? `Gate ${m.arrival_gate}` : null]
            .filter(Boolean).join(" · ") || "—"}
        </p>
        {m.accommodation_address && (
          <p className="text-mid text-sm pt-2">Adresse: <span className="text-navy">{m.accommodation_address}</span></p>
        )}
      </div>

      {/* PRIMARY TAP */}
      {tap_ !== "DONE" ? (
        <button
          onClick={() => tap.mutate({ kind: tapMeta.kind, title: tapMeta.title })}
          disabled={tap.isPending}
          className="w-full bg-navy text-cream font-serif text-2xl py-8 transition-colors hover:bg-gold disabled:opacity-50 mb-4"
        >
          {tap.isPending ? "…" : tapMeta.label}
        </button>
      ) : (
        <div className="w-full border border-gold text-navy font-serif text-2xl py-8 text-center mb-4">
          Übergabe abgeschlossen.
        </div>
      )}

      <button
        onClick={() => setBlockerOpen((v) => !v)}
        className="w-full text-sm text-mid hover:text-navy py-3 border-b border-border transition-colors"
      >
        {blockerOpen ? "Abbrechen" : "Blocker melden"}
      </button>

      {blockerOpen && (
        <div className="mt-6 space-y-4">
          <textarea
            value={blockerText}
            onChange={(e) => setBlockerText(e.target.value)}
            placeholder="Was hindert dich gerade? Eine kurze Zeile reicht."
            rows={3}
            className="w-full border border-border bg-cream p-4 font-serif text-lg text-navy placeholder:text-mid placeholder:font-sans placeholder:text-sm focus:outline-none focus:border-navy"
          />
          <button
            onClick={() => blockerText.trim() && reportBlocker.mutate(blockerText.trim())}
            disabled={!blockerText.trim() || reportBlocker.isPending}
            className="text-navy border-b border-navy pb-1 hover:text-gold hover:border-gold disabled:opacity-50 transition-colors"
          >
            {reportBlocker.isPending ? "Senden …" : "Blocker senden"}
          </button>
        </div>
      )}

      {/* Offene Blocker */}
      {initial.blockers.length > 0 && (
        <div className="mt-12">
          <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-4">Offen</p>
          <ul className="space-y-3">
            {initial.blockers.map((b: any) => (
              <li key={b.id} className="flex items-start justify-between gap-6 border-b border-border pb-3">
                <span className="text-navy">{b.reason}</span>
                <button
                  onClick={() => resolve.mutate(b.id)}
                  disabled={resolve.isPending}
                  className="text-xs uppercase tracking-[0.2em] text-mid hover:text-gold disabled:opacity-50 transition-colors shrink-0"
                >
                  erledigt
                </button>
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Kuratierte Timeline */}
      {initial.lastEvents.length > 0 && (
        <div className="mt-14">
          <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-5">Verlauf</p>
          <ol className="space-y-5">
            {initial.lastEvents.map((e: any) => (
              <li key={e.id} className="grid grid-cols-[6rem_1fr] gap-6 text-sm">
                <span className="font-serif italic text-gold pt-0.5">{formatRelative(e.created_at)}</span>
                <span className="text-navy leading-snug">
                  {eventToHumanLine(e, "greeter", { talentName: t.full_name })}
                </span>
              </li>
            ))}
          </ol>
        </div>
      )}
    </section>
  );
}
