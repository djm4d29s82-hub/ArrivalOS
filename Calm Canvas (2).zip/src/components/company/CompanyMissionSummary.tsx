import { useEffect } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { getCompanyMissionDetail } from "@/lib/portal.functions";
import { resolveBlocker } from "@/lib/operations.functions";
import { eventToHumanLine } from "@/lib/eventTaxonomy";
import { formatRelative } from "@/lib/relativeTime";
import { PortalHeader, GroupLabel, MetaRow } from "@/components/portal/PortalShell";

function fmtDateTime(iso: string | null) {
  if (!iso) return null;
  return new Date(iso).toLocaleString("de-DE", { hour: "2-digit", minute: "2-digit", day: "2-digit", month: "short" });
}

function statusLabel(s: string) {
  return ({ draft: "Entwurf", confirmed: "Bestätigt", in_progress: "Läuft gerade", completed: "Abgeschlossen", cancelled: "Abgebrochen" } as Record<string, string>)[s] ?? s;
}

function nextStepText(eventKinds: string[], hasGreeter: boolean): string {
  const set = new Set(eventKinds);
  if (set.has("HANDOVER_COMPLETED")) return "Übergabe ist abgeschlossen.";
  if (set.has("EN_ROUTE")) return "Unterwegs zur Unterkunft.";
  if (set.has("TALENT_PICKED_UP")) return "Fahrt zur Unterkunft steht an.";
  if (hasGreeter) return "Greeter holt Talent am Flughafen ab.";
  return "Greeter muss noch zugewiesen werden.";
}

export function CompanyMissionSummary({ missionId }: { missionId: string }) {
  const qc = useQueryClient();
  const fn = useServerFn(getCompanyMissionDetail);
  const clearBlk = useServerFn(resolveBlocker);
  const { data } = useQuery({
    queryKey: ["company-mission-detail", missionId],
    queryFn: () => fn({ data: { missionId } }),
  });

  useEffect(() => {
    const ch = supabase
      .channel(`co-mission-${missionId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "mission_events", filter: `mission_id=eq.${missionId}` },
        () => qc.invalidateQueries({ queryKey: ["company-mission-detail", missionId] }))
      .on("postgres_changes", { event: "*", schema: "public", table: "blockers", filter: `mission_id=eq.${missionId}` },
        () => qc.invalidateQueries({ queryKey: ["company-mission-detail", missionId] }))
      .on("postgres_changes", { event: "UPDATE", schema: "public", table: "missions", filter: `id=eq.${missionId}` },
        () => qc.invalidateQueries({ queryKey: ["company-mission-detail", missionId] }))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [missionId, qc]);

  const resolve = useMutation({
    mutationFn: async (blockerId: string) => clearBlk({ data: { blockerId } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["company-mission-detail", missionId] }),
  });

  if (!data) return <p className="text-mid italic text-sm px-8 md:px-16 py-16">Einen Moment …</p>;
  if (!data.mission) {
    return (
      <section className="px-8 md:px-16 py-20">
        <p className="font-serif text-2xl text-navy">Diese Mission existiert nicht oder ist nicht zugänglich.</p>
        <Link to="/portal" className="mt-8 inline-block text-sm border-b border-navy pb-1 text-navy hover:text-gold hover:border-gold transition-colors">Zurück</Link>
      </section>
    );
  }

  const m = data.mission;
  const eventKinds = (data.curatedEvents ?? []).map((e: any) => e.kind);
  const hasOpenBlocker = data.openBlockers.length > 0;
  const ownerLabels: Record<string, string> = { admin: "NeuLand", company: "Unternehmen", greeter: "Greeter", talent: "Talent" };

  return (
    <>
      <PortalHeader
        eyebrow={`${m.city}${m.scheduled_arrival ? ` · Ankunft ${fmtDateTime(m.scheduled_arrival)}` : ""}`}
        title={data.talent.full_name ?? "—"}
        sub={undefined}
      />

      <section className="px-8 md:px-16 pt-12 max-w-3xl">
        {/* DECISION BLOCK */}
        <div className={`border ${hasOpenBlocker ? "border-gold bg-gold/5" : "border-border"} p-8 md:p-10 mb-12`}>
          {hasOpenBlocker ? (
            <>
              <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-5">Blocker</p>
              <ul className="space-y-4">
                {data.openBlockers.map((b: any) => (
                  <li key={b.id} className="flex items-start justify-between gap-8">
                    <div className="min-w-0">
                      <p className="font-serif text-2xl text-navy leading-snug">{b.reason}</p>
                      <p className="text-xs uppercase tracking-[0.2em] text-mid mt-2">
                        seit {formatRelative(b.created_at)}
                        {b.owner_role ? ` · Owner: ${ownerLabels[b.owner_role] ?? b.owner_role}` : ""}
                      </p>
                    </div>
                    <button
                      onClick={() => resolve.mutate(b.id)}
                      disabled={resolve.isPending}
                      className="text-xs uppercase tracking-[0.2em] text-mid hover:text-navy disabled:opacity-50 transition-colors shrink-0"
                    >
                      gelöst
                    </button>
                  </li>
                ))}
              </ul>
            </>
          ) : (
            <p className="font-serif text-2xl text-navy">
              <span className="text-gold">✓</span> Alles auf Kurs.
            </p>
          )}
        </div>

        {/* OPERATIONAL FACTS */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6 mb-16">
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-2">Status</p>
            <p className="font-serif text-xl text-navy">{statusLabel(m.status)}</p>
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-2">Nächster Schritt</p>
            <p className="font-serif text-xl text-navy">{nextStepText(eventKinds, !!data.greeter)}</p>
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-2">Letzte Bewegung</p>
            <p className="font-serif text-xl text-navy">
              {data.lastEvent
                ? eventToHumanLine(data.lastEvent, "company", { talentName: data.talent.full_name, greeterName: data.greeter?.full_name })
                : "—"}
            </p>
            {data.lastEvent && <p className="text-xs uppercase tracking-[0.2em] text-mid mt-2">{formatRelative(data.lastEvent.created_at)}</p>}
          </div>
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-2">Begleitung</p>
            <p className="font-serif text-xl text-navy">{data.greeter?.full_name ?? "Noch nicht zugewiesen"}</p>
            {data.greeter?.languages && data.greeter.languages.length > 0 && (
              <p className="text-mid text-sm mt-1">spricht {data.greeter.languages.join(", ")}</p>
            )}
          </div>
        </div>
      </section>

      <section className="px-8 md:px-16 pb-20 grid grid-cols-1 md:grid-cols-[2fr_1fr] gap-16 max-w-6xl">
        <div>
          <GroupLabel>Verlauf</GroupLabel>
          {data.curatedEvents.length === 0 ? (
            <p className="text-mid italic">Noch keine operativen Ereignisse.</p>
          ) : (
            <ol className="space-y-7">
              {data.curatedEvents.map((e: any) => (
                <li key={e.id} className="grid grid-cols-[6rem_1fr] gap-6">
                  <span className="font-serif italic text-gold text-sm pt-0.5">{formatRelative(e.created_at)}</span>
                  <span className="text-navy leading-snug">
                    {eventToHumanLine(e, "company", { talentName: data.talent.full_name, greeterName: data.greeter?.full_name })}
                  </span>
                </li>
              ))}
            </ol>
          )}
        </div>
        <div>
          <GroupLabel>Eckdaten</GroupLabel>
          <div className="border-y border-border">
            <MetaRow label="Flug" value={[m.airline, m.flight_number].filter(Boolean).join(" ") || "—"} />
            <MetaRow label="Ankunft" value={fmtDateTime(m.scheduled_arrival) ?? "—"} />
            <MetaRow label="Flughafen" value={[m.arrival_airport, m.arrival_terminal, m.arrival_gate].filter(Boolean).join(" · ") || "—"} />
            <MetaRow label="Unterkunft" value={m.accommodation_address ?? "—"} />
            <MetaRow label="Zeitraum" value={`${m.starts_at ?? "—"} → ${m.ends_at ?? "—"}`} />
          </div>
          {data.documents.length > 0 && (
            <>
              <GroupLabel className="mt-10">Dokumente</GroupLabel>
              <ul className="border-y border-border divide-y divide-border">
                {data.documents.map((d: any) => (
                  <li key={d.id} className="py-4 flex justify-between gap-4 text-sm">
                    <span className="text-navy">{d.title}</span>
                    <span className={`text-xs uppercase tracking-[0.2em] ${d.status === "received" ? "text-gold" : "text-mid"}`}>
                      {d.status === "received" ? "vorhanden" : "ausstehend"}
                    </span>
                  </li>
                ))}
              </ul>
            </>
          )}
          <Link to="/portal" className="mt-10 inline-block text-sm border-b border-navy pb-1 text-navy hover:text-gold hover:border-gold transition-colors">
            Zurück zur Übersicht
          </Link>
        </div>
      </section>
    </>
  );
}
