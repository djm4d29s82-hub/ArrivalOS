import { useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { useQuery } from "@tanstack/react-query";
import { getTalentNextStep } from "@/lib/portal.functions";
import { deriveTalentState, talentCopy, type Locale } from "@/lib/talentCopy";
import { PortalHeader } from "@/components/portal/PortalShell";

function monogram(name: string | null) {
  if (!name) return "·";
  return name.split(" ").filter(Boolean).slice(0, 2).map((w) => w[0]?.toUpperCase()).join("");
}

export function TalentNextStepPanel() {
  const fn = useServerFn(getTalentNextStep);
  const { data } = useQuery({ queryKey: ["talent-next-step"], queryFn: () => fn() });
  const [override, setOverride] = useState<Locale | null>(null);

  if (!data) return <p className="text-mid italic text-sm px-8 md:px-16 py-16">Einen Moment …</p>;

  const locale: Locale = override ?? (data.locale as Locale) ?? "de";
  const state = deriveTalentState({
    hasMission: !!data.mission,
    hasGreeter: !!data.greeter,
    eventKinds: data.eventKinds,
    hasOpenBlockerOwnedByTalent: data.openBlockerOwnedByTalent,
  });

  const ctx = {
    greeterName: data.greeter?.full_name ?? null,
    greeterLanguages: data.greeter?.languages ?? [],
    city: data.mission?.city ?? null,
    address: data.mission?.accommodation_address ?? null,
  };

  const copy = talentCopy(state, locale, ctx);
  const t = locale === "de"
    ? { who: "Wer dich begleitet", where: "Wo du hin wirst", lang: "spricht" }
    : { who: "Who is with you", where: "Where you'll go", lang: "speaks" };

  return (
    <>
      <div className="flex justify-end px-8 md:px-16 pt-8 -mb-4">
        <button
          onClick={() => setOverride(locale === "de" ? "en" : "de")}
          className="text-[11px] uppercase tracking-[0.28em] text-mid hover:text-navy transition-colors"
        >
          {locale === "de" ? "EN" : "DE"}
        </button>
      </div>
      <PortalHeader
        eyebrow={data.mission?.city ?? "—"}
        title={copy.headline}
        sub={copy.sub}
      />

      <section className="px-8 md:px-16 py-16 md:py-20 max-w-2xl space-y-14">
        {data.greeter && (
          <div className="flex items-start gap-6">
            {data.greeter.avatar_url ? (
              <img src={data.greeter.avatar_url} alt={data.greeter.full_name ?? ""} className="h-20 w-20 object-cover shrink-0" />
            ) : (
              <div className="h-20 w-20 shrink-0 bg-navy text-cream font-serif text-2xl flex items-center justify-center">
                {monogram(data.greeter.full_name)}
              </div>
            )}
            <div className="pt-1">
              <p className="text-[11px] uppercase tracking-[0.28em] text-mid">{t.who}</p>
              <p className="font-serif text-2xl text-navy mt-2">{data.greeter.full_name ?? "—"}</p>
              {data.greeter.languages.length > 0 && (
                <p className="text-mid text-sm mt-1">{t.lang} {data.greeter.languages.join(", ")}</p>
              )}
            </div>
          </div>
        )}

        {data.mission?.accommodation_address && (
          <div>
            <p className="text-[11px] uppercase tracking-[0.28em] text-mid mb-2">{t.where}</p>
            <p className="font-serif text-xl text-navy leading-snug">{data.mission.accommodation_address}</p>
          </div>
        )}
      </section>
    </>
  );
}
