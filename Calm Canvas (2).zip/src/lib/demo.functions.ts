import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

const DemoRoleSchema = z.enum(["talent", "greeter", "company", "admin"]);
export type DemoRole = z.infer<typeof DemoRoleSchema>;

const DEMO_PASSWORD = "neuland-demo-2026";
const DEMO_FLAG = { is_demo: true } as const;

const demoAccounts: Record<DemoRole, { email: string; fullName: string }> = {
  talent: { email: "demo.talent@neuland.app", fullName: "Amara Okafor" },
  greeter: { email: "demo.greeter@neuland.app", fullName: "Jonas Weber" },
  company: { email: "demo.company@neuland.app", fullName: "Lena Vogt · Krane GmbH" },
  admin: { email: "demo.admin@neuland.app", fullName: "Mira Halberg" },
};

const extraTalents = [
  { email: "demo.talent.liang@neuland.app", fullName: "Liang Chen", home: "China", city: "Berlin" },
  { email: "demo.talent.sofia@neuland.app", fullName: "Sofia Marín", home: "Argentinien", city: "Berlin" },
];

/**
 * GATE: Demo is a DEVELOPMENT MODE, not a feature.
 * Only callable by admins (or in local dev). Anything else throws.
 */
async function assertDemoAccess(userId: string) {
  if (process.env.NODE_ENV !== "production") return; // DEV: free
  const { data } = await supabaseAdmin
    .from("user_roles").select("role").eq("user_id", userId).eq("role", "admin").maybeSingle();
  if (!data) throw new Error("Demo tools are admin-only.");
}

async function ensureUser(opts: { email: string; fullName: string }) {
  const { data: list } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 1000 });
  const existing = list?.users.find((u) => u.email === opts.email);
  if (existing) return { id: existing.id, ...opts };
  const { data, error } = await supabaseAdmin.auth.admin.createUser({
    email: opts.email,
    password: DEMO_PASSWORD,
    email_confirm: true,
    user_metadata: { full_name: opts.fullName },
  });
  if (error || !data.user) throw new Error(error?.message ?? "Could not create demo user");
  return { id: data.user.id, ...opts };
}

function minutesFromNow(min: number) {
  return new Date(Date.now() + min * 60 * 1000).toISOString();
}
function daysFromNow(d: number) {
  return new Date(Date.now() + d * 24 * 3600 * 1000).toISOString().slice(0, 10);
}

async function seedAll() {
  const talent = await ensureUser(demoAccounts.talent);
  const greeter = await ensureUser(demoAccounts.greeter);
  const company = await ensureUser(demoAccounts.company);
  const admin = await ensureUser(demoAccounts.admin);
  const liang = await ensureUser(extraTalents[0]);
  const sofia = await ensureUser(extraTalents[1]);

  const allTalentIds = [talent.id, liang.id, sofia.id];

  // Mark demo profiles
  await supabaseAdmin.from("profiles").update({ is_demo: true })
    .in("id", [talent.id, greeter.id, company.id, admin.id, liang.id, sofia.id]);

  // Roles
  await supabaseAdmin.from("user_roles").upsert(
    [
      { user_id: talent.id, role: "talent" as const, ...DEMO_FLAG },
      { user_id: liang.id, role: "talent" as const, ...DEMO_FLAG },
      { user_id: sofia.id, role: "talent" as const, ...DEMO_FLAG },
      { user_id: greeter.id, role: "greeter" as const, ...DEMO_FLAG },
      { user_id: company.id, role: "company" as const, ...DEMO_FLAG },
      { user_id: admin.id, role: "admin" as const, ...DEMO_FLAG },
    ],
    { onConflict: "user_id,role" },
  );

  // Company
  const { data: existingCompany } = await supabaseAdmin
    .from("companies").select("id").eq("name", "Krane GmbH").maybeSingle();
  let companyId = existingCompany?.id;
  if (!companyId) {
    const { data } = await supabaseAdmin
      .from("companies")
      .insert({ name: "Krane GmbH", contact_email: "people@krane.example", city: "Berlin", ...DEMO_FLAG })
      .select("id").single();
    companyId = data!.id;
  }
  await supabaseAdmin.from("company_members").upsert(
    { company_id: companyId, user_id: company.id, ...DEMO_FLAG },
    { onConflict: "company_id,user_id" },
  );

  // Greeter profile
  await supabaseAdmin.from("greeters").upsert(
    {
      user_id: greeter.id,
      city: "Berlin",
      languages: ["Deutsch", "English", "Türkçe"],
      bio: "Geboren in Kreuzberg, lebt seit immer in Berlin. Liebt Kaffee, lange Spaziergänge und kennt jede Behörde beim Vornamen.",
      available: true,
      ...DEMO_FLAG,
    },
    { onConflict: "user_id" },
  );

  // Reset talents + everything mission-related for our three demo talents
  await supabaseAdmin.from("talents").upsert(
    [
      { user_id: talent.id, company_id: companyId, home_country: "Nigeria", arrival_date: daysFromNow(-4), city: "Berlin", ...DEMO_FLAG },
      { user_id: liang.id, company_id: companyId, home_country: "China", arrival_date: daysFromNow(-1), city: "Berlin", ...DEMO_FLAG },
      { user_id: sofia.id, company_id: companyId, home_country: "Argentinien", arrival_date: daysFromNow(1), city: "Berlin", ...DEMO_FLAG },
    ],
    { onConflict: "user_id" },
  );

  // Wipe demo missions for these talents
  const { data: oldMissions } = await supabaseAdmin
    .from("missions").select("id").in("talent_id", allTalentIds);
  const oldIds = (oldMissions ?? []).map((m) => m.id);
  if (oldIds.length) {
    await supabaseAdmin.from("messages").delete().in("mission_id", oldIds);
    await supabaseAdmin.from("mission_events").delete().in("mission_id", oldIds);
    await supabaseAdmin.from("documents").delete().in("mission_id", oldIds);
    await supabaseAdmin.from("missions").delete().in("id", oldIds);
  }
  await supabaseAdmin.from("documents").delete().in("owner_user_id", allTalentIds);

  // === Mission 1: Amara — laufend ===
  const { data: m1 } = await supabaseAdmin.from("missions").insert({
    talent_id: talent.id, greeter_id: greeter.id, company_id: companyId,
    city: "Berlin", status: "in_progress",
    starts_at: daysFromNow(-4), ends_at: daysFromNow(38),
    summary: "Sechs Wochen Ankunftsbegleitung in Berlin.", ...DEMO_FLAG,
  }).select("id").single();
  const m1Id = m1!.id;

  await supabaseAdmin.from("mission_events").insert([
    { mission_id: m1Id, kind: "created", title: "Mission angelegt", created_by: admin.id, created_at: minutesFromNow(-14 * 24 * 60), ...DEMO_FLAG },
    { mission_id: m1Id, kind: "greeter_assigned", title: "Greeter bestätigt", body: "Jonas hat zugesagt.", created_by: greeter.id, created_at: minutesFromNow(-12 * 24 * 60), ...DEMO_FLAG },
    { mission_id: m1Id, kind: "arrival", title: "Am Flughafen abgeholt", body: "Ankunft am BER, Tegel-Café, dann ins Apartment.", created_by: greeter.id, created_at: minutesFromNow(-4 * 24 * 60), ...DEMO_FLAG },
    { mission_id: m1Id, kind: "anmeldung", title: "Anmeldung im Bürgeramt", body: "Termin gemeinsam wahrgenommen, Meldebescheinigung erhalten.", created_by: greeter.id, created_at: minutesFromNow(-2 * 24 * 60), ...DEMO_FLAG },
    { mission_id: m1Id, kind: "wohnung_uebergeben", title: "Wohnung übergeben", body: "Schlüssel sind da, WLAN läuft.", created_by: greeter.id, created_at: minutesFromNow(-14), ...DEMO_FLAG },
    { mission_id: m1Id, kind: "note", title: "Termin Steueranmeldung", body: "Gemeinsamer Termin im Finanzamt.", created_by: greeter.id, created_at: minutesFromNow(60 * 24 + 30), ...DEMO_FLAG },
  ]);

  await supabaseAdmin.from("documents").insert([
    { owner_user_id: talent.id, mission_id: m1Id, kind: "passport", title: "Reisepass", status: "received", ...DEMO_FLAG },
    { owner_user_id: talent.id, mission_id: m1Id, kind: "anmeldung", title: "Meldebescheinigung", status: "received", ...DEMO_FLAG },
    { owner_user_id: talent.id, mission_id: m1Id, kind: "tax_id", title: "Steuer-ID", status: "pending", ...DEMO_FLAG },
  ]);

  await supabaseAdmin.from("messages").insert([
    { mission_id: m1Id, from_user_id: greeter.id, body: "Willkommen in Berlin! Ich bin Jonas, dein Greeter. Wir sehen uns morgen um 9.", created_at: minutesFromNow(-5 * 24 * 60), ...DEMO_FLAG },
    { mission_id: m1Id, from_user_id: talent.id, body: "Danke, Jonas. Ich freue mich!", created_at: minutesFromNow(-5 * 24 * 60 + 60), ...DEMO_FLAG },
  ]);

  // === Mission 2: Liang — gerade gelandet ===
  const { data: m2 } = await supabaseAdmin.from("missions").insert({
    talent_id: liang.id, greeter_id: greeter.id, company_id: companyId,
    city: "Berlin", status: "in_progress",
    starts_at: daysFromNow(-1), ends_at: daysFromNow(41),
    summary: "Sechs Wochen Ankunftsbegleitung in Berlin.", ...DEMO_FLAG,
  }).select("id").single();
  const m2Id = m2!.id;

  await supabaseAdmin.from("mission_events").insert([
    { mission_id: m2Id, kind: "created", title: "Mission angelegt", created_by: admin.id, created_at: minutesFromNow(-10 * 24 * 60), ...DEMO_FLAG },
    { mission_id: m2Id, kind: "greeter_assigned", title: "Greeter bestätigt", created_by: greeter.id, created_at: minutesFromNow(-9 * 24 * 60), ...DEMO_FLAG },
    { mission_id: m2Id, kind: "talent_gelandet", title: "Talent ist gelandet", body: "Ankunft Terminal 1, Greeter wartet am Ausgang.", created_by: greeter.id, created_at: minutesFromNow(-90), ...DEMO_FLAG },
    { mission_id: m2Id, kind: "gepaeck", title: "Gepäck abgeholt", created_by: greeter.id, created_at: minutesFromNow(-45), ...DEMO_FLAG },
    { mission_id: m2Id, kind: "fahrt", title: "Fahrt läuft", body: "Unterwegs ins Apartment in Prenzlauer Berg.", created_by: greeter.id, created_at: minutesFromNow(-12), ...DEMO_FLAG },
    { mission_id: m2Id, kind: "note", title: "Wohnungsübergabe heute Abend", created_by: greeter.id, created_at: minutesFromNow(60 * 4), ...DEMO_FLAG },
  ]);

  await supabaseAdmin.from("documents").insert([
    { owner_user_id: liang.id, mission_id: m2Id, kind: "passport", title: "Reisepass", status: "received", ...DEMO_FLAG },
    { owner_user_id: liang.id, mission_id: m2Id, kind: "anmeldung", title: "Meldebescheinigung", status: "pending", ...DEMO_FLAG },
    { owner_user_id: liang.id, mission_id: m2Id, kind: "tax_id", title: "Steuer-ID", status: "pending", ...DEMO_FLAG },
  ]);

  // === Mission 3: Sofia — startet morgen ===
  const { data: m3 } = await supabaseAdmin.from("missions").insert({
    talent_id: sofia.id, greeter_id: greeter.id, company_id: companyId,
    city: "Berlin", status: "confirmed",
    starts_at: daysFromNow(1), ends_at: daysFromNow(43),
    summary: "Ankunft morgen Vormittag.", ...DEMO_FLAG,
  }).select("id").single();
  const m3Id = m3!.id;

  await supabaseAdmin.from("mission_events").insert([
    { mission_id: m3Id, kind: "created", title: "Mission angelegt", created_by: admin.id, created_at: minutesFromNow(-7 * 24 * 60), ...DEMO_FLAG },
    { mission_id: m3Id, kind: "greeter_assigned", title: "Greeter bestätigt", created_by: greeter.id, created_at: minutesFromNow(-6 * 24 * 60), ...DEMO_FLAG },
    { mission_id: m3Id, kind: "greeter_unterwegs", title: "Greeter ist unterwegs", body: "Abholung morgen 10:40 am BER.", created_by: greeter.id, created_at: minutesFromNow(60 * 20), ...DEMO_FLAG },
  ]);

  await supabaseAdmin.from("documents").insert([
    { owner_user_id: sofia.id, mission_id: m3Id, kind: "passport", title: "Reisepass", status: "received", ...DEMO_FLAG },
    { owner_user_id: sofia.id, mission_id: m3Id, kind: "tax_id", title: "Steuer-ID", status: "pending", ...DEMO_FLAG },
  ]);

  return { email: demoAccounts.talent.email, password: DEMO_PASSWORD };
}

/**
 * Seed + return demo credentials. Admin-only outside DEV.
 */
export const seedDemoAndGetCredentials = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { role: DemoRole }) => ({ role: DemoRoleSchema.parse(input.role) }))
  .handler(async ({ data, context }) => {
    await assertDemoAccess(context.userId);
    await seedAll();
    return {
      email: demoAccounts[data.role].email,
      password: DEMO_PASSWORD,
    };
  });

/**
 * Switch into a demo account (full session replace). Admin-only outside DEV.
 * Returns a magic-link action URL that signs the caller in as the target role.
 */
export const switchToDemoAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { role: DemoRole }) => ({ role: DemoRoleSchema.parse(input.role) }))
  .handler(async ({ data, context }) => {
    await assertDemoAccess(context.userId);
    const email = demoAccounts[data.role].email;
    return { email, password: DEMO_PASSWORD };
  });
