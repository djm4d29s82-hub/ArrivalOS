// Warm German relative time + narrative event labels.
// Used across portal views to give the platform a sense of live presence.

export function formatRelative(iso: string | null | undefined): string {
  if (!iso) return "—";
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return "—";
  const now = Date.now();
  const diffSec = Math.round((then - now) / 1000);
  const abs = Math.abs(diffSec);
  const past = diffSec < 0;

  // < 60s
  if (abs < 60) return past ? "gerade eben" : "in wenigen Sekunden";
  // < 60min
  if (abs < 3600) {
    const m = Math.round(abs / 60);
    return past ? `vor ${m} Min` : `in ${m} Min`;
  }
  const today = new Date();
  const that = new Date(iso);
  const sameDay =
    that.getFullYear() === today.getFullYear() &&
    that.getMonth() === today.getMonth() &&
    that.getDate() === today.getDate();
  const hh = String(that.getHours()).padStart(2, "0");
  const mm = String(that.getMinutes()).padStart(2, "0");
  const time = `${hh}:${mm}`;

  if (sameDay) {
    if (abs < 6 * 3600) {
      const h = Math.round(abs / 3600);
      return past ? `vor ${h} Std` : `in ${h} Std`;
    }
    return past ? `heute ${time}` : `heute ${time}`;
  }

  const yesterday = new Date(today);
  yesterday.setDate(today.getDate() - 1);
  const tomorrow = new Date(today);
  tomorrow.setDate(today.getDate() + 1);

  const sameDate = (a: Date, b: Date) =>
    a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();

  if (sameDate(that, yesterday)) return `gestern ${time}`;
  if (sameDate(that, tomorrow)) return `morgen ${time}`;

  // within a week → weekday + time
  if (abs < 7 * 24 * 3600) {
    const weekday = that.toLocaleDateString("de-DE", { weekday: "long" });
    return `${weekday} ${time}`;
  }

  // fallback: short date
  return that.toLocaleDateString("de-DE", { day: "2-digit", month: "short" });
}

// Narrative labels for mission_events.kind.
// Fallback returns the raw kind; safe for free-form strings.
export function labelKind(kind: string | null | undefined): string {
  if (!kind) return "—";
  const map: Record<string, string> = {
    // narrative
    greeter_unterwegs: "Greeter ist unterwegs",
    talent_gelandet: "Talent ist gelandet",
    gepaeck: "Gepäck abgeholt",
    fahrt: "Fahrt läuft",
    wohnung_uebergeben: "Wohnung übergeben",
    // existing
    created: "Mission angelegt",
    greeter_assigned: "Greeter bestätigt",
    arrival: "Am Flughafen abgeholt",
    anmeldung: "Anmeldung im Bürgeramt",
    note: "Notiz",
    // documents
    passport: "Pass",
    tax_id: "Steuer-ID",
    visa: "Visum",
    contract: "Vertrag",
    insurance: "Versicherung",
    other: "Sonstiges",
  };
  return map[kind] ?? kind;
}
