import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { supabaseAdmin } from "@/integrations/supabase/client.server";
import { buildKernel } from "./missionKernel";
import { formatRelative } from "./relativeTime";

export const getMyRoles = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", userId);
    if (error) throw new Error(error.message);
    const { data: profile } = await supabase
      .from("profiles").select("full_name").eq("id", userId).maybeSingle();
    return {
      userId,
      roles: (data ?? []).map((r) => r.role as string),
      fullName: profile?.full_name ?? null,
    };
  });

/**
 * Self-signup contract: if a signed-in user has no role yet, claim the
 * `talent` role for themselves. Idempotent. Talent is the ONLY role that
 * can be self-assigned — greeter/company/admin must be granted by an admin.
 */
export const claimTalentRole = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { userId } = context;
    const { data: existing } = await supabaseAdmin
      .from("user_roles").select("role").eq("user_id", userId);
    if ((existing ?? []).length > 0) return { ok: true, alreadyHadRole: true };
    const { error } = await supabaseAdmin
      .from("user_roles").insert({ user_id: userId, role: "talent" });
    if (error) throw new Error(error.message);
    return { ok: true, alreadyHadRole: false };
  });

export const getTalentJourney = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const active = await supabase
      .from("missions").select("*").eq("talent_id", userId).eq("status", "in_progress")
      .order("created_at", { ascending: false }).limit(1).maybeSingle();
    const fallback = active.data
      ? { data: active.data }
      : await supabase
          .from("missions").select("*").eq("talent_id", userId)
          .order("created_at", { ascending: false }).limit(1).maybeSingle();
    const mission = fallback.data;
    if (!mission) return { mission: null, events: [], greeter: null, nextStep: null, pendingDocsCount: 0 };

    const [{ data: events }, { data: greeterProfile }, { data: greeter }, { data: docs }] = await Promise.all([
      supabase.from("mission_events").select("*").eq("mission_id", mission.id).order("created_at", { ascending: true }),
      mission.greeter_id
        ? supabase.from("profiles").select("id, full_name, avatar_url").eq("id", mission.greeter_id).maybeSingle()
        : Promise.resolve({ data: null }),
      mission.greeter_id
        ? supabase.from("greeters").select("*").eq("user_id", mission.greeter_id).maybeSingle()
        : Promise.resolve({ data: null }),
      supabase.from("documents").select("status").eq("owner_user_id", userId),
    ]);

    const now = Date.now();
    const nextStep = (events ?? []).find((e) => new Date(e.created_at).getTime() > now) ?? null;
    const pendingDocsCount = (docs ?? []).filter((d: any) => d.status !== "received").length;

    // Enrich events with creator name
    const creatorIds = Array.from(new Set((events ?? []).map((e: any) => e.created_by).filter(Boolean)));
    const { data: creators } = creatorIds.length
      ? await supabase.from("profiles").select("id, full_name").in("id", creatorIds)
      : { data: [] };
    const creatorMap = new Map((creators ?? []).map((c: any) => [c.id, c.full_name]));
    const enrichedEvents = (events ?? []).map((e: any) => ({
      ...e,
      created_by_name: e.created_by ? creatorMap.get(e.created_by) ?? null : null,
    }));

    const kernel = buildKernel(mission, (events ?? []) as any, (docs ?? []) as any);
    return {
      mission,
      events: enrichedEvents,
      greeter: greeterProfile && greeter ? { ...greeterProfile, ...greeter } : null,
      nextStep,
      pendingDocsCount,
      kernel,
    };
  });

export const getTalentDocuments = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("documents")
      .select("*")
      .eq("owner_user_id", userId)
      .order("created_at", { ascending: true });
    if (error) throw new Error(error.message);
    return { documents: data ?? [] };
  });

export const getGreeterOverview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const [{ data: greeter }, { data: missions }] = await Promise.all([
      supabase.from("greeters").select("*").eq("user_id", userId).maybeSingle(),
      supabase.from("missions")
        .select("*")
        .eq("greeter_id", userId)
        .order("starts_at", { ascending: true }),
    ]);

    const talentIds = (missions ?? []).map((m) => m.talent_id);
    const missionIds = (missions ?? []).map((m) => m.id);
    const [{ data: talents }, { data: events }, { data: docs }] = await Promise.all([
      talentIds.length
        ? supabase.from("profiles").select("id, full_name").in("id", talentIds)
        : Promise.resolve({ data: [] }),
      missionIds.length
        ? supabase.from("mission_events").select("mission_id, created_at, title, kind").in("mission_id", missionIds).order("created_at", { ascending: false })
        : Promise.resolve({ data: [] }),
      missionIds.length
        ? supabase.from("documents").select("mission_id, kind, title, status").in("mission_id", missionIds)
        : Promise.resolve({ data: [] }),
    ]);

    const byId = new Map((talents ?? []).map((t: any) => [t.id, t.full_name]));
    const eventsByMission = new Map<string, any[]>();
    for (const e of events ?? []) {
      const arr = eventsByMission.get(e.mission_id) ?? [];
      arr.push(e);
      eventsByMission.set(e.mission_id, arr);
    }
    const docsByMission = new Map<string, any[]>();
    for (const d of docs ?? []) {
      if (!d.mission_id) continue;
      const arr = docsByMission.get(d.mission_id) ?? [];
      arr.push(d);
      docsByMission.set(d.mission_id, arr);
    }
    const lastEventByMission = new Map<string, { created_at: string; title: string; kind: string }>();
    const nextStepByMission = new Map<string, { created_at: string; title: string; kind: string }>();
    const nowMs = Date.now();
    for (const e of events ?? []) {
      const ts = new Date(e.created_at).getTime();
      if (ts <= nowMs && !lastEventByMission.has(e.mission_id)) {
        lastEventByMission.set(e.mission_id, { created_at: e.created_at, title: e.title, kind: e.kind });
      }
    }
    const future = (events ?? []).filter((e: any) => new Date(e.created_at).getTime() > nowMs).slice().reverse();
    for (const e of future) {
      if (!nextStepByMission.has(e.mission_id)) {
        nextStepByMission.set(e.mission_id, { created_at: e.created_at, title: e.title, kind: e.kind });
      }
    }
    const enriched = (missions ?? []).map((m) => {
      const last = lastEventByMission.get(m.id);
      const next = nextStepByMission.get(m.id);
      const kernel = buildKernel(m, eventsByMission.get(m.id) ?? [], docsByMission.get(m.id) ?? []);
      return {
        ...m,
        talent_name: byId.get(m.talent_id) ?? "—",
        last_event_at: last?.created_at ?? null,
        last_event_title: last?.title ?? null,
        last_event_kind: last?.kind ?? null,
        next_step_at: next?.created_at ?? null,
        next_step_title: next?.title ?? null,
        next_step_kind: next?.kind ?? null,
        kernel,
      };
    });
    const current = enriched.find((m) => m.status === "in_progress") ?? null;
    const upcoming = enriched.filter((m) => m.status === "confirmed" || m.status === "draft");
    return { greeter, current, upcoming, all: enriched };
  });

export const setGreeterAvailability = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { available: boolean }) => ({ available: !!input.available }))
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const { error } = await supabase
      .from("greeters")
      .update({ available: data.available })
      .eq("user_id", userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const updateGreeterProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { bio?: string; city?: string }) => ({
    bio: typeof input.bio === "string" ? input.bio.slice(0, 1000) : undefined,
    city: typeof input.city === "string" ? input.city.slice(0, 100) : undefined,
  }))
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const patch: { bio?: string; city?: string } = {};
    if (data.bio !== undefined) patch.bio = data.bio;
    if (data.city !== undefined) patch.city = data.city;
    if (Object.keys(patch).length === 0) return { ok: true };
    const { error } = await supabase.from("greeters").update(patch).eq("user_id", userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// =================== COMPANY ===================
export const getCompanyOverview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: memberships } = await supabase
      .from("company_members").select("company_id").eq("user_id", userId);
    const companyIds = (memberships ?? []).map((m) => m.company_id);
    if (companyIds.length === 0) return { company: null, missions: [], statusCounts: {} as Record<string, number> };

    const [{ data: company }, { data: missions }] = await Promise.all([
      supabase.from("companies").select("*").in("id", companyIds).limit(1).maybeSingle(),
      supabase.from("missions").select("*").in("company_id", companyIds)
        .order("starts_at", { ascending: false }),
    ]);

    const talentIds = Array.from(new Set((missions ?? []).map((m) => m.talent_id)));
    const greeterIds = Array.from(new Set((missions ?? []).map((m) => m.greeter_id).filter(Boolean) as string[]));
    const allIds = Array.from(new Set([...talentIds, ...greeterIds]));
    const missionIds = (missions ?? []).map((m) => m.id);
    const [{ data: people }, { data: events }, { data: docs }] = await Promise.all([
      allIds.length
        ? supabase.from("profiles").select("id, full_name").in("id", allIds)
        : Promise.resolve({ data: [] }),
      missionIds.length
        ? supabase.from("mission_events").select("mission_id, created_at, title, kind").in("mission_id", missionIds).order("created_at", { ascending: false })
        : Promise.resolve({ data: [] }),
      missionIds.length
        ? supabase.from("documents").select("mission_id, kind, title, status").in("mission_id", missionIds)
        : Promise.resolve({ data: [] }),
    ]);
    const byId = new Map((people ?? []).map((p: any) => [p.id, p.full_name]));
    const nowMs = Date.now();
    const lastEventByMission = new Map<string, { created_at: string; title: string; kind: string }>();
    const nextStepByMission = new Map<string, { created_at: string; title: string; kind: string }>();
    for (const e of events ?? []) {
      const ts = new Date(e.created_at).getTime();
      if (ts <= nowMs && !lastEventByMission.has(e.mission_id)) {
        lastEventByMission.set(e.mission_id, { created_at: e.created_at, title: e.title, kind: e.kind });
      }
    }
    const future = (events ?? []).filter((e: any) => new Date(e.created_at).getTime() > nowMs).slice().reverse();
    for (const e of future) {
      if (!nextStepByMission.has(e.mission_id)) {
        nextStepByMission.set(e.mission_id, { created_at: e.created_at, title: e.title, kind: e.kind });
      }
    }
    const eventsByMission = new Map<string, any[]>();
    for (const e of events ?? []) {
      const arr = eventsByMission.get(e.mission_id) ?? [];
      arr.push(e);
      eventsByMission.set(e.mission_id, arr);
    }
    const docsByMission = new Map<string, any[]>();
    for (const d of docs ?? []) {
      if (!d.mission_id) continue;
      const arr = docsByMission.get(d.mission_id) ?? [];
      arr.push(d);
      docsByMission.set(d.mission_id, arr);
    }

    const enriched = (missions ?? []).map((m) => {
      const last = lastEventByMission.get(m.id);
      const next = nextStepByMission.get(m.id);
      const kernel = buildKernel(m, eventsByMission.get(m.id) ?? [], docsByMission.get(m.id) ?? []);
      return {
        ...m,
        talent_name: byId.get(m.talent_id) ?? "—",
        greeter_name: m.greeter_id ? byId.get(m.greeter_id) ?? "—" : null,
        last_event_at: last?.created_at ?? null,
        last_event_title: last?.title ?? null,
        last_event_kind: last?.kind ?? null,
        next_step_at: next?.created_at ?? null,
        next_step_title: next?.title ?? null,
        next_step_kind: next?.kind ?? null,
        events: (eventsByMission.get(m.id) ?? []).slice().reverse(),
        kernel,
      };
    });
    const statusCounts: Record<string, number> = {};
    for (const m of enriched) statusCounts[m.status] = (statusCounts[m.status] ?? 0) + 1;
    const lastUpdateAt = (events ?? [])[0]?.created_at ?? null;
    return { company, missions: enriched, statusCounts, lastUpdateAt };
  });

// =================== ADMIN ===================
export const getAdminOverview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: roles } = await supabase.from("user_roles").select("role").eq("user_id", userId);
    if (!(roles ?? []).some((r) => r.role === "admin")) {
      throw new Error("Forbidden");
    }
    const [{ data: missions }, { data: profiles }, { data: companies }, { data: greeters }] = await Promise.all([
      supabase.from("missions").select("*").order("created_at", { ascending: false }).limit(100),
      supabase.from("profiles").select("id, full_name"),
      supabase.from("companies").select("*").order("name", { ascending: true }),
      supabase.from("greeters").select("*"),
    ]);
    const byId = new Map((profiles ?? []).map((p: any) => [p.id, p.full_name]));
    const companyById = new Map((companies ?? []).map((c: any) => [c.id, c.name]));

    const missionIds = (missions ?? []).map((m) => m.id);
    const [{ data: events }, { data: docs }] = await Promise.all([
      missionIds.length
        ? supabase.from("mission_events").select("mission_id, created_at, title, kind").in("mission_id", missionIds).order("created_at", { ascending: false })
        : Promise.resolve({ data: [] }),
      missionIds.length
        ? supabase.from("documents").select("mission_id, kind, title, status").in("mission_id", missionIds)
        : Promise.resolve({ data: [] }),
    ]);
    const nowMs = Date.now();
    const lastByMission = new Map<string, { created_at: string; title: string; kind: string }>();
    const nextByMission = new Map<string, { created_at: string; title: string; kind: string }>();
    const eventsByMission = new Map<string, any[]>();
    for (const e of events ?? []) {
      const arr = eventsByMission.get(e.mission_id) ?? [];
      arr.push(e);
      eventsByMission.set(e.mission_id, arr);
      if (new Date(e.created_at).getTime() <= nowMs && !lastByMission.has(e.mission_id)) {
        lastByMission.set(e.mission_id, { created_at: e.created_at, title: e.title, kind: e.kind });
      }
    }
    const future = (events ?? []).filter((e: any) => new Date(e.created_at).getTime() > nowMs).slice().reverse();
    for (const e of future) {
      if (!nextByMission.has(e.mission_id)) {
        nextByMission.set(e.mission_id, { created_at: e.created_at, title: e.title, kind: e.kind });
      }
    }
    const docsByMission = new Map<string, any[]>();
    for (const d of docs ?? []) {
      if (!d.mission_id) continue;
      const arr = docsByMission.get(d.mission_id) ?? [];
      arr.push(d);
      docsByMission.set(d.mission_id, arr);
    }

    const enriched = (missions ?? []).map((m) => {
      const last = lastByMission.get(m.id);
      const next = nextByMission.get(m.id);
      const kernel = buildKernel(m, eventsByMission.get(m.id) ?? [], docsByMission.get(m.id) ?? []);
      return {
        ...m,
        talent_name: byId.get(m.talent_id) ?? "—",
        greeter_name: m.greeter_id ? byId.get(m.greeter_id) ?? "—" : null,
        company_name: m.company_id ? companyById.get(m.company_id) ?? "—" : null,
        last_event_at: last?.created_at ?? null,
        last_event_title: last?.title ?? null,
        last_event_kind: last?.kind ?? null,
        next_step_at: next?.created_at ?? null,
        next_step_title: next?.title ?? null,
        next_step_kind: next?.kind ?? null,
        kernel,
      };
    });

    const companyMissionCounts = new Map<string, number>();
    for (const m of missions ?? []) {
      if (m.company_id) companyMissionCounts.set(m.company_id, (companyMissionCounts.get(m.company_id) ?? 0) + 1);
    }
    const companiesEnriched = (companies ?? []).map((c: any) => ({
      ...c,
      mission_count: companyMissionCounts.get(c.id) ?? 0,
    }));

    const greetersEnriched = (greeters ?? []).map((g: any) => {
      const active = enriched.find((m) => m.greeter_id === g.user_id && m.status === "in_progress");
      return {
        ...g,
        full_name: byId.get(g.user_id) ?? "—",
        active_talent_name: active?.talent_name ?? null,
        active_city: active?.city ?? null,
        active_last_event_title: active?.last_event_title ?? null,
        active_last_event_at: active?.last_event_at ?? null,
        active_kernel: active?.kernel ?? null,
      };
    });

    const statusCounts: Record<string, number> = {};
    for (const m of enriched) statusCounts[m.status] = (statusCounts[m.status] ?? 0) + 1;
    const lastUpdateAt = (events ?? [])[0]?.created_at ?? null;

    return { missions: enriched, companies: companiesEnriched, greeters: greetersEnriched, statusCounts, lastUpdateAt };
  });

// SYSTEM SNAPSHOT entfernt: erzeugte Narrative ("läuft gerade", "steht bevor",
// "Nächste Bewegung", "Risiken heute") statt reiner Zustände. Verstößt gegen
// Core-Regel: Zustände zeigen, keine Narrative.

// =====================================================================
// Phase 1B — Operational read functions for the three surfaces
// =====================================================================

import { z } from "zod";
import { curateEvents } from "./eventTaxonomy";

const UuidArg = z.string().uuid();

/**
 * Greeter Action Surface — heutige (= nächste offene, nicht abgeschlossene)
 * Mission für den eingeloggten Greeter. Liefert alles, was die Action-View
 * in einer Fläche braucht: Talent-Profil, Flug, Adresse, offene Blocker,
 * kuratierte letzten Events, plus die Event-Kinds zur Tap-Ableitung.
 */
export const getGreeterTodayMission = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: missions } = await supabase
      .from("missions")
      .select("*")
      .eq("greeter_id", userId)
      .neq("status", "completed")
      .neq("status", "cancelled")
      .order("scheduled_arrival", { ascending: true, nullsFirst: false })
      .order("starts_at", { ascending: true, nullsFirst: false })
      .limit(5);

    const mission = (missions ?? [])[0] ?? null;
    if (!mission) {
      // Optional: nächste konfirmierte Mission als Vorschau
      const { data: nextList } = await supabase
        .from("missions")
        .select("id, city, starts_at, scheduled_arrival, talent_id")
        .eq("greeter_id", userId)
        .order("scheduled_arrival", { ascending: true, nullsFirst: false })
        .limit(1);
      const next = (nextList ?? [])[0] ?? null;
      let nextTalentName: string | null = null;
      if (next?.talent_id) {
        const { data: p } = await supabase.from("profiles").select("full_name").eq("id", next.talent_id).maybeSingle();
        nextTalentName = p?.full_name ?? null;
      }
      return { mission: null, next: next ? { ...next, talent_name: nextTalentName } : null };
    }

    const [{ data: talentProfile }, { data: talent }, { data: events }, { data: blockers }] = await Promise.all([
      supabase.from("profiles").select("id, full_name, avatar_url").eq("id", mission.talent_id).maybeSingle(),
      supabase.from("talents").select("photo_url, languages, home_country, city").eq("user_id", mission.talent_id).maybeSingle(),
      supabase.from("mission_events").select("*").eq("mission_id", mission.id).order("created_at", { ascending: true }),
      supabase.from("blockers").select("*").eq("mission_id", mission.id).is("resolved_at", null).order("created_at", { ascending: false }),
    ]);

    const curated = curateEvents((events ?? []) as any[]);
    const eventKinds = curated.map((e: any) => e.kind);
    const lastEvents = curated.slice(-5).reverse();

    return {
      mission,
      talent: {
        id: mission.talent_id,
        full_name: talentProfile?.full_name ?? null,
        photo_url: talent?.photo_url ?? talentProfile?.avatar_url ?? null,
        languages: talent?.languages ?? [],
        home_country: talent?.home_country ?? null,
      },
      eventKinds,
      lastEvents,
      blockers: blockers ?? [],
      next: null,
    };
  });

/**
 * Company Decision Surface — voller Mission-Detail.
 */
export const getCompanyMissionDetail = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { missionId: string }) => ({ missionId: UuidArg.parse(input.missionId) }))
  .handler(async ({ context, data }) => {
    const { supabase } = context;
    const { data: mission, error } = await supabase
      .from("missions").select("*").eq("id", data.missionId).maybeSingle();
    if (error) throw new Error(error.message);
    if (!mission) return { mission: null };

    const [
      { data: talentProfile },
      { data: talent },
      { data: greeterProfile },
      { data: greeter },
      { data: events },
      { data: blockers },
      { data: docs },
    ] = await Promise.all([
      supabase.from("profiles").select("id, full_name, avatar_url").eq("id", mission.talent_id).maybeSingle(),
      supabase.from("talents").select("photo_url, languages, home_country, city").eq("user_id", mission.talent_id).maybeSingle(),
      mission.greeter_id
        ? supabase.from("profiles").select("id, full_name").eq("id", mission.greeter_id).maybeSingle()
        : Promise.resolve({ data: null }),
      mission.greeter_id
        ? supabase.from("greeters").select("languages, city, bio").eq("user_id", mission.greeter_id).maybeSingle()
        : Promise.resolve({ data: null }),
      supabase.from("mission_events").select("*").eq("mission_id", data.missionId).order("created_at", { ascending: false }),
      supabase.from("blockers").select("*").eq("mission_id", data.missionId).order("created_at", { ascending: false }),
      supabase.from("documents").select("id, title, kind, status").eq("mission_id", data.missionId),
    ]);

    const allEvents = (events ?? []) as any[];
    const curated = curateEvents(allEvents);
    const lastEvent = curated[0] ?? null;
    const openBlockers = (blockers ?? []).filter((b: any) => !b.resolved_at);

    return {
      mission,
      talent: {
        id: mission.talent_id,
        full_name: talentProfile?.full_name ?? null,
        photo_url: talent?.photo_url ?? talentProfile?.avatar_url ?? null,
        languages: talent?.languages ?? [],
        home_country: talent?.home_country ?? null,
      },
      greeter: greeterProfile
        ? {
            id: greeterProfile.id,
            full_name: greeterProfile.full_name,
            languages: greeter?.languages ?? [],
            city: greeter?.city ?? null,
          }
        : null,
      curatedEvents: curated.slice(0, 10),
      lastEvent,
      openBlockers,
      allBlockers: blockers ?? [],
      documents: docs ?? [],
    };
  });

/**
 * Talent Next-Step — minimaler Datenslice für das Panel.
 */
export const getTalentNextStep = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data: mission } = await supabase
      .from("missions")
      .select("*")
      .eq("talent_id", userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    const { data: profile } = await supabase
      .from("profiles").select("full_name, locale").eq("id", userId).maybeSingle();

    if (!mission) {
      return { mission: null, locale: (profile?.locale as "de" | "en") ?? "de", greeter: null, eventKinds: [], openBlockerOwnedByTalent: false };
    }

    const [{ data: events }, { data: blockers }, { data: greeterProfile }, { data: greeter }] = await Promise.all([
      supabase.from("mission_events").select("kind").eq("mission_id", mission.id),
      supabase.from("blockers").select("*").eq("mission_id", mission.id).is("resolved_at", null),
      mission.greeter_id
        ? supabase.from("profiles").select("id, full_name, avatar_url").eq("id", mission.greeter_id).maybeSingle()
        : Promise.resolve({ data: null }),
      mission.greeter_id
        ? supabase.from("greeters").select("languages, city").eq("user_id", mission.greeter_id).maybeSingle()
        : Promise.resolve({ data: null }),
    ]);

    const ownedByTalent = (blockers ?? []).some(
      (b: any) => b.owner_user_id === userId || b.owner_role === "talent",
    );

    return {
      mission,
      locale: (profile?.locale as "de" | "en") ?? "de",
      greeter: greeterProfile
        ? {
            id: greeterProfile.id,
            full_name: greeterProfile.full_name,
            avatar_url: greeterProfile.avatar_url,
            languages: greeter?.languages ?? [],
          }
        : null,
      eventKinds: (events ?? []).map((e: any) => e.kind),
      openBlockerOwnedByTalent: ownedByTalent,
    };
  });


