// Talent-facing copy. Status-Codes existieren hier nicht — nur Sätze.
// Bewusst flach: kein i18n-Framework, nur eine Map mit DE/EN.

export type Locale = "de" | "en";

export type TalentState =
  | "no_mission"
  | "draft_no_greeter"
  | "assigned_waiting"
  | "flight_delayed"
  | "picked_up"
  | "en_route"
  | "handover_done"
  | "blocked_on_talent";

export function deriveTalentState(input: {
  hasMission: boolean;
  hasGreeter: boolean;
  eventKinds: string[];
  hasOpenBlockerOwnedByTalent: boolean;
}): TalentState {
  if (!input.hasMission) return "no_mission";
  if (input.hasOpenBlockerOwnedByTalent) return "blocked_on_talent";
  const set = new Set(input.eventKinds);
  if (set.has("HANDOVER_COMPLETED")) return "handover_done";
  if (set.has("EN_ROUTE")) return "en_route";
  if (set.has("TALENT_PICKED_UP")) return "picked_up";
  if (set.has("FLIGHT_DELAYED")) return "flight_delayed";
  if (input.hasGreeter) return "assigned_waiting";
  return "draft_no_greeter";
}

type Copy = { headline: string; sub: (ctx: Ctx) => string };
type Ctx = {
  greeterName?: string | null;
  greeterLanguages?: string[];
  city?: string | null;
  address?: string | null;
};

const COPY: Record<Locale, Record<TalentState, Copy>> = {
  de: {
    no_mission: {
      headline: "Bald geht es los.",
      sub: () => "Sobald deine Reise bestätigt ist, siehst du hier den nächsten Schritt.",
    },
    draft_no_greeter: {
      headline: "Wir suchen die richtige Person für dich.",
      sub: () => "Du erfährst es als Erste, sobald dein Greeter feststeht.",
    },
    assigned_waiting: {
      headline: "Du wirst am Flughafen abgeholt.",
      sub: (c) =>
        c.greeterName
          ? `${c.greeterName} kommt zu dir${c.greeterLanguages?.length ? ` — spricht ${c.greeterLanguages.join(", ")}` : ""}.`
          : "Dein Greeter wartet auf dich.",
    },
    flight_delayed: {
      headline: "Wir haben deine neue Ankunftszeit.",
      sub: (c) => `${c.greeterName ?? "Dein Greeter"} ist informiert und wartet auf dich.`,
    },
    picked_up: {
      headline: "Du bist abgeholt.",
      sub: (c) => (c.address ? `Nächster Schritt: Fahrt zu ${c.address}.` : "Nächster Schritt: Fahrt zur Unterkunft."),
    },
    en_route: {
      headline: "Ihr seid unterwegs.",
      sub: (c) => (c.address ? `Ziel: ${c.address}.` : "Bald an der Unterkunft."),
    },
    handover_done: {
      headline: "Angekommen.",
      sub: () => "Ruh dich aus. Morgen meldet sich deine Ansprechpartnerin.",
    },
    blocked_on_talent: {
      headline: "Wir brauchen noch etwas von dir.",
      sub: () => "Schau bitte in deine Nachrichten — eine Kleinigkeit fehlt noch.",
    },
  },
  en: {
    no_mission: {
      headline: "Coming soon.",
      sub: () => "Once your journey is confirmed, your next step will appear here.",
    },
    draft_no_greeter: {
      headline: "We are matching you with the right person.",
      sub: () => "You'll be the first to know once your greeter is assigned.",
    },
    assigned_waiting: {
      headline: "You'll be picked up at the airport.",
      sub: (c) =>
        c.greeterName
          ? `${c.greeterName} will meet you${c.greeterLanguages?.length ? ` — speaks ${c.greeterLanguages.join(", ")}` : ""}.`
          : "Your greeter will be waiting for you.",
    },
    flight_delayed: {
      headline: "We've seen your new arrival time.",
      sub: (c) => `${c.greeterName ?? "Your greeter"} has been informed.`,
    },
    picked_up: {
      headline: "You're picked up.",
      sub: (c) => (c.address ? `Next: drive to ${c.address}.` : "Next: drive to your accommodation."),
    },
    en_route: {
      headline: "On your way.",
      sub: (c) => (c.address ? `Destination: ${c.address}.` : "Almost there."),
    },
    handover_done: {
      headline: "Arrived.",
      sub: () => "Rest well. Your contact will reach out tomorrow.",
    },
    blocked_on_talent: {
      headline: "We need something from you.",
      sub: () => "Please check your messages — one small thing is missing.",
    },
  },
};

export function talentCopy(state: TalentState, locale: Locale, ctx: Ctx) {
  const c = COPY[locale][state];
  return { headline: c.headline, sub: c.sub(ctx) };
}
