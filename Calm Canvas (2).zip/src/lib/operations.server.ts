// Server-only helpers for operations.functions.ts
// Kept separate per tss-serverfn-split rule: .functions.ts must stay thin.

import type { SupabaseClient } from "@supabase/supabase-js";

/**
 * Event taxonomy — klein und klar gehalten.
 * Status wird daraus abgeleitet, nicht direkt gesetzt.
 */
export const EVENT_KINDS = [
  "MISSION_CREATED",
  "GREETER_ASSIGNED",
  "GREETER_UNASSIGNED",
  "FLIGHT_INFO_UPDATED",
  "FLIGHT_DELAYED",
  "TALENT_PICKED_UP",
  "EN_ROUTE",
  "HANDOVER_COMPLETED",
  "APARTMENT_KEYS_TRANSFERRED",
  "CHECKIN_COMPLETED",
  "BLOCKER_SET",
  "BLOCKER_RESOLVED",
  "DOCUMENT_RECEIVED",
  "NOTE_ADDED",
] as const;
export type EventKind = (typeof EVENT_KINDS)[number];

/**
 * Single source of truth for status transitions.
 * Returning null = no status change for this event.
 */
export function deriveStatusFromEvent(kind: EventKind): string | null {
  switch (kind) {
    case "MISSION_CREATED":
      return "draft";
    case "GREETER_ASSIGNED":
      return "confirmed";
    case "TALENT_PICKED_UP":
    case "EN_ROUTE":
      return "in_progress";
    case "HANDOVER_COMPLETED":
    case "CHECKIN_COMPLETED":
      return "completed";
    default:
      return null;
  }
}

/**
 * Resolve the most relevant role of `userId` *for this specific mission*.
 * Order of precedence: admin > company-member > greeter (assigned) > talent.
 * Returns null if the user has no relationship to the mission.
 */
export async function resolveActorRoleForMission(
  supabase: SupabaseClient,
  userId: string,
  missionId: string,
): Promise<string | null> {
  const { data: roles } = await supabase
    .from("user_roles").select("role").eq("user_id", userId);
  const roleSet = new Set((roles ?? []).map((r) => r.role as string));
  if (roleSet.has("admin")) return "admin";

  const { data: mission } = await supabase
    .from("missions").select("talent_id, greeter_id, company_id").eq("id", missionId).maybeSingle();
  if (!mission) return null;

  if (mission.company_id) {
    const { data: memberships } = await supabase
      .from("company_members").select("company_id").eq("user_id", userId).eq("company_id", mission.company_id);
    if ((memberships ?? []).length > 0) return "company";
  }
  if (mission.greeter_id === userId) return "greeter";
  if (mission.talent_id === userId) return "talent";
  return null;
}
