import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import {
  EVENT_KINDS,
  deriveStatusFromEvent,
  resolveActorRoleForMission,
  type EventKind,
} from "./operations.server";

const EventKindSchema = z.enum(EVENT_KINDS);
const UuidSchema = z.string().uuid();

// =====================================================================
// EVENTS — append-only Wahrheit. Status wird hier (und nur hier) abgeleitet.
// =====================================================================

export const postMissionEvent = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      missionId: UuidSchema,
      kind: EventKindSchema,
      title: z.string().min(1).max(200),
      body: z.string().max(2000).optional(),
      payload: z.record(z.string(), z.unknown()).optional(),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const actorRole = await resolveActorRoleForMission(supabase, userId, data.missionId);
    if (!actorRole) throw new Error("Not allowed to post events on this mission");

    const { data: event, error } = await supabase
      .from("mission_events")
      .insert({
        mission_id: data.missionId,
        kind: data.kind,
        title: data.title,
        body: data.body ?? null,
        payload: (data.payload ?? {}) as any,
        created_by: userId,
        actor_role: actorRole as any,
      })
      .select("*").single();
    if (error) throw new Error(error.message);

    // Derived status update — only the kernel writes status.
    const nextStatus = deriveStatusFromEvent(data.kind as EventKind);
    if (nextStatus) {
      const { error: upd } = await supabase
        .from("missions").update({ status: nextStatus as any }).eq("id", data.missionId);
      if (upd) throw new Error(upd.message);
    }
    return { event, statusChangedTo: nextStatus };
  });

// =====================================================================
// BLOCKERS — First-Class
// =====================================================================

export const setBlocker = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      missionId: UuidSchema,
      reason: z.string().min(1).max(300),
      payload: z.record(z.string(), z.unknown()).optional(),
      ownerUserId: UuidSchema.optional(),
      ownerRole: z.enum(["admin", "company", "greeter", "talent"]).optional(),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const actorRole = await resolveActorRoleForMission(supabase, userId, data.missionId);
    if (!actorRole) throw new Error("Not allowed");

    const { data: blocker, error } = await supabase
      .from("blockers").insert({
        mission_id: data.missionId,
        reason: data.reason,
        payload: (data.payload ?? {}) as any,
        owner_user_id: data.ownerUserId ?? null,
        owner_role: (data.ownerRole as any) ?? null,
        created_by: userId,
      }).select("*").single();
    if (error) throw new Error(error.message);

    await supabase.from("mission_events").insert({
      mission_id: data.missionId,
      kind: "BLOCKER_SET",
      title: data.reason,
      payload: { blocker_id: blocker.id, ...(data.payload ?? {}) },
      created_by: userId,
      actor_role: actorRole as any,
    });
    return { blocker };
  });

export const resolveBlocker = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ blockerId: UuidSchema }).parse(input))
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const { data: blocker } = await supabase
      .from("blockers").select("mission_id, reason, resolved_at").eq("id", data.blockerId).maybeSingle();
    if (!blocker) throw new Error("Blocker not found");
    if (blocker.resolved_at) return { ok: true, alreadyResolved: true };

    const actorRole = await resolveActorRoleForMission(supabase, userId, blocker.mission_id);
    if (!actorRole) throw new Error("Not allowed");

    const { error } = await supabase
      .from("blockers")
      .update({ resolved_at: new Date().toISOString(), resolved_by: userId })
      .eq("id", data.blockerId);
    if (error) throw new Error(error.message);

    await supabase.from("mission_events").insert({
      mission_id: blocker.mission_id,
      kind: "BLOCKER_RESOLVED",
      title: blocker.reason,
      payload: { blocker_id: data.blockerId },
      created_by: userId,
      actor_role: actorRole as any,
    });
    return { ok: true };
  });

// =====================================================================
// ASSIGNMENTS — Greeter zuweisen / abziehen (admin oder company)
// =====================================================================

export const assignGreeter = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      missionId: UuidSchema,
      greeterUserId: UuidSchema,
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const actorRole = await resolveActorRoleForMission(supabase, userId, data.missionId);
    if (actorRole !== "admin" && actorRole !== "company") {
      throw new Error("Only admin or company can assign greeters");
    }

    // Close any open greeter assignment first
    await supabase
      .from("mission_assignments")
      .update({ unassigned_at: new Date().toISOString() })
      .eq("mission_id", data.missionId)
      .eq("role", "greeter")
      .is("unassigned_at", null);

    const { data: assignment, error } = await supabase
      .from("mission_assignments").insert({
        mission_id: data.missionId,
        user_id: data.greeterUserId,
        role: "greeter",
        assigned_by: userId,
      }).select("*").single();
    if (error) throw new Error(error.message);

    // Denormalized cache on missions
    await supabase.from("missions")
      .update({ greeter_id: data.greeterUserId, status: "confirmed" as any })
      .eq("id", data.missionId);

    await supabase.from("mission_events").insert({
      mission_id: data.missionId,
      kind: "GREETER_ASSIGNED",
      title: "Greeter zugewiesen",
      payload: { greeter_user_id: data.greeterUserId, assignment_id: assignment.id },
      created_by: userId,
      actor_role: actorRole as any,
    });
    return { assignment };
  });

// =====================================================================
// MISSIONS — create + operational update
// =====================================================================

export const createMission = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      companyId: UuidSchema,
      talentUserId: UuidSchema,
      city: z.string().min(1).max(120),
      startsAt: z.string().optional(),
      endsAt: z.string().optional(),
      summary: z.string().max(2000).optional(),
      airline: z.string().max(120).optional(),
      flightNumber: z.string().max(20).optional(),
      arrivalAirport: z.string().max(120).optional(),
      arrivalTerminal: z.string().max(20).optional(),
      arrivalGate: z.string().max(20).optional(),
      scheduledArrival: z.string().optional(),
      accommodationAddress: z.string().max(300).optional(),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const { data: roles } = await supabase
      .from("user_roles").select("role").eq("user_id", userId);
    const isAdmin = (roles ?? []).some((r) => r.role === "admin");
    if (!isAdmin) {
      const { data: memberships } = await supabase
        .from("company_members").select("company_id").eq("user_id", userId).eq("company_id", data.companyId);
      if ((memberships ?? []).length === 0) {
        throw new Error("Not a member of this company");
      }
    }

    const { data: mission, error } = await supabase
      .from("missions").insert({
        company_id: data.companyId,
        talent_id: data.talentUserId,
        city: data.city,
        starts_at: data.startsAt ?? null,
        ends_at: data.endsAt ?? null,
        summary: data.summary ?? null,
        status: "draft" as any,
        airline: data.airline ?? null,
        flight_number: data.flightNumber ?? null,
        arrival_airport: data.arrivalAirport ?? null,
        arrival_terminal: data.arrivalTerminal ?? null,
        arrival_gate: data.arrivalGate ?? null,
        scheduled_arrival: data.scheduledArrival ?? null,
        accommodation_address: data.accommodationAddress ?? null,
      }).select("*").single();
    if (error) throw new Error(error.message);

    await supabase.from("mission_events").insert({
      mission_id: mission.id,
      kind: "MISSION_CREATED",
      title: `Mission ${data.city}`,
      payload: { company_id: data.companyId, talent_id: data.talentUserId },
      created_by: userId,
      actor_role: (isAdmin ? "admin" : "company") as any,
    });
    return { mission };
  });

export const updateMissionDetails = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      missionId: UuidSchema,
      patch: z.object({
        city: z.string().min(1).max(120).optional(),
        starts_at: z.string().nullable().optional(),
        ends_at: z.string().nullable().optional(),
        summary: z.string().max(2000).nullable().optional(),
        airline: z.string().max(120).nullable().optional(),
        flight_number: z.string().max(20).nullable().optional(),
        arrival_airport: z.string().max(120).nullable().optional(),
        arrival_terminal: z.string().max(20).nullable().optional(),
        arrival_gate: z.string().max(20).nullable().optional(),
        scheduled_arrival: z.string().nullable().optional(),
        actual_arrival: z.string().nullable().optional(),
        accommodation_address: z.string().max(300).nullable().optional(),
      }),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const actorRole = await resolveActorRoleForMission(supabase, userId, data.missionId);
    if (!actorRole || actorRole === "talent") throw new Error("Not allowed");

    const { data: mission, error } = await supabase
      .from("missions").update(data.patch).eq("id", data.missionId).select("*").single();
    if (error) throw new Error(error.message);

    const flightTouched = ["airline", "flight_number", "arrival_airport", "arrival_terminal",
      "arrival_gate", "scheduled_arrival"].some((k) => k in data.patch);
    if (flightTouched) {
      await supabase.from("mission_events").insert({
        mission_id: data.missionId,
        kind: "FLIGHT_INFO_UPDATED",
        title: "Fluginfo aktualisiert",
        payload: data.patch,
        created_by: userId,
        actor_role: actorRole as any,
      });
    }
    return { mission };
  });

// =====================================================================
// TALENT PROFILE — operative Felder
// =====================================================================

export const updateTalentProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      userId: UuidSchema,
      patch: z.object({
        photo_url: z.string().url().nullable().optional(),
        languages: z.array(z.string().min(1).max(40)).max(20).optional(),
        recruiter_notes: z.string().max(4000).nullable().optional(),
        home_country: z.string().max(120).nullable().optional(),
        arrival_date: z.string().nullable().optional(),
        city: z.string().max(120).nullable().optional(),
      }),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase } = context;
    // RLS enforces: self, company member, or admin.
    const { data: talent, error } = await supabase
      .from("talents").update(data.patch).eq("user_id", data.userId).select("*").maybeSingle();
    if (error) throw new Error(error.message);
    return { talent };
  });

// =====================================================================
// DOCUMENTS — record + mark received
// =====================================================================

export const recordDocument = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) =>
    z.object({
      missionId: UuidSchema.optional(),
      ownerUserId: UuidSchema,
      kind: z.string().min(1).max(80),
      title: z.string().min(1).max(200),
      storagePath: z.string().max(500).optional(),
    }).parse(input),
  )
  .handler(async ({ context, data }) => {
    const { supabase } = context;
    const { data: doc, error } = await supabase
      .from("documents").insert({
        mission_id: data.missionId ?? null,
        owner_user_id: data.ownerUserId,
        kind: data.kind,
        title: data.title,
        storage_path: data.storagePath ?? null,
        status: "pending",
      }).select("*").single();
    if (error) throw new Error(error.message);
    return { document: doc };
  });

export const markDocumentReceived = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input) => z.object({ documentId: UuidSchema }).parse(input))
  .handler(async ({ context, data }) => {
    const { supabase, userId } = context;
    const { data: doc, error } = await supabase
      .from("documents").update({ status: "received" }).eq("id", data.documentId)
      .select("*").single();
    if (error) throw new Error(error.message);

    if (doc.mission_id) {
      const actorRole = await resolveActorRoleForMission(supabase, userId, doc.mission_id);
      if (actorRole) {
        await supabase.from("mission_events").insert({
          mission_id: doc.mission_id,
          kind: "DOCUMENT_RECEIVED",
          title: doc.title,
          payload: { document_id: doc.id, kind: doc.kind },
          created_by: userId,
          actor_role: actorRole as any,
        });
      }
    }
    return { document: doc };
  });
