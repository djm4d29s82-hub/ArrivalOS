// Mission Truth Layer.
// Code-only. No text, no sentences, no view-specific decisions.
// Renderer (`src/lib/missionRenderer.ts`) maps these codes to language per view.
//
// ARCHITEKTUR-INVARIANTEN (verbindlich, nicht verhandelbar):
//  - NEXT = Action auf Mission-Ebene (was passiert als nächstes mit DIESER Mission).
//  - FLOW gehört NICHT in den Kernel. System-weite Timing-Narrative wurden
//    bewusst entfernt — Views zeigen rohe Zustände, keine zusammenfassenden
//    Story-Texte. Wenn so eine Ebene jemals zurückkehrt, lebt sie außerhalb
//    des Kernels und darf keinen Kernel-Code beeinflussen.
//  - Active Presence ist ein Rendering-Resultat, KEIN Kernel-Kriterium.
//    Wenn ein Kernel "leer" wirkt, ist das ein Daten-/Event-Problem,
//    niemals ein Auftrag, Codes für UI-Wirkung zu erfinden.
//  - Der Kernel darf keine UI-Wirkung garantieren. Codes spiegeln Wahrheit,
//    nicht Wirkung. "Optimieren für Präsenz" ist Drift und verboten.
//
// QA: Kernel Stability Test — gleicher Kernel MUSS in allen Views identische
// Code-Basis (state.code, next.code, blockers[].code) zeigen. Unterschiede
// dürfen nur in der gerenderten Sprache existieren.

export type StateCode =
  | "mission_draft"
  | "mission_confirmed"
  | "mission_in_progress"
  | "mission_completed"
  | "mission_cancelled"
  | "greeter_assigned"
  | "greeter_unterwegs"
  | "talent_gelandet"
  | "gepaeck"
  | "fahrt"
  | "wohnung_uebergeben"
  | "arrival"
  | "anmeldung"
  | "created"
  | "note"
  | (string & {}); // unknown event kinds pass through; renderer fallback shows the code itself

export type NextCode = StateCode | "documents_awaited";

export type BlockerCode =
  | "passport_missing"
  | "tax_id_missing"
  | "visa_missing"
  | "contract_missing"
  | "insurance_missing"
  | "other_missing"
  | "plus_n_more"
  | (string & {});

export type MissionKernel = {
  state: { code: StateCode; since: string | null };
  next: { code: NextCode; when: string | null } | null;
  blockers: { code: BlockerCode; count?: number }[];
};

type Event = { created_at: string; title: string; kind: string };
type Doc = { kind: string; title: string | null; status: string };

const STATUS_CODE: Record<string, StateCode> = {
  draft: "mission_draft",
  confirmed: "mission_confirmed",
  in_progress: "mission_in_progress",
  completed: "mission_completed",
  cancelled: "mission_cancelled",
};

const DOC_BLOCKER: Record<string, BlockerCode> = {
  passport: "passport_missing",
  tax_id: "tax_id_missing",
  visa: "visa_missing",
  contract: "contract_missing",
  insurance: "insurance_missing",
};

export function buildKernel(
  mission: { status: string },
  events: Event[],
  docs: Doc[],
): MissionKernel {
  const now = Date.now();
  const sorted = events.slice().sort((a, b) => +new Date(a.created_at) - +new Date(b.created_at));
  const past = sorted.filter((e) => +new Date(e.created_at) <= now);
  const future = sorted.filter((e) => +new Date(e.created_at) > now);

  const last = past[past.length - 1] ?? null;
  const first = future[0] ?? null;

  const state: MissionKernel["state"] = last
    ? { code: last.kind, since: last.created_at }
    : { code: STATUS_CODE[mission.status] ?? "mission_draft", since: null };

  const missing = docs.filter((d) => d.status !== "received");
  let next: MissionKernel["next"] = null;
  if (first) {
    next = { code: first.kind, when: first.created_at };
  } else if (missing.length > 0) {
    next = { code: "documents_awaited", when: null };
  }

  const head = missing.slice(0, 3).map<MissionKernel["blockers"][number]>((d) => ({
    code: DOC_BLOCKER[d.kind] ?? "other_missing",
  }));
  const blockers: MissionKernel["blockers"] =
    missing.length > 3
      ? [...head, { code: "plus_n_more", count: missing.length - 3 }]
      : head;

  return { state, next, blockers };
}
