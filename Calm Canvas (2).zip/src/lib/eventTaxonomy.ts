// Event-Whitelist + human-readable Übersetzung.
// Roh-Events sind im Stream, sichtbar wird nur, was operativ relevant ist.

export const OPERATIONAL_EVENTS = new Set<string>([
  "MISSION_CREATED",
  "GREETER_ASSIGNED",
  "GREETER_UNASSIGNED",
  "FLIGHT_DELAYED",
  "FLIGHT_INFO_UPDATED",
  "TALENT_PICKED_UP",
  "EN_ROUTE",
  "HANDOVER_COMPLETED",
  "APARTMENT_KEYS_TRANSFERRED",
  "CHECKIN_COMPLETED",
  "BLOCKER_SET",
  "BLOCKER_RESOLVED",
  "DOCUMENT_RECEIVED",
]);

export type Audience = "company" | "greeter" | "talent";

export function isOperational(kind: string): boolean {
  return OPERATIONAL_EVENTS.has(kind);
}

export function curateEvents<T extends { kind: string }>(events: T[]): T[] {
  return events.filter((e) => OPERATIONAL_EVENTS.has(e.kind));
}

/**
 * Eine Funktion, drei Tonalitäten.
 * `subject` ist der jeweilige Name (Talent für Greeter/Company, Greeter für Talent).
 */
export function eventToHumanLine(
  event: { kind: string; title?: string | null; body?: string | null },
  audience: Audience,
  ctx: { talentName?: string | null; greeterName?: string | null } = {},
): string {
  const t = ctx.talentName ?? "Talent";
  const g = ctx.greeterName ?? "Greeter";
  switch (event.kind) {
    case "MISSION_CREATED":
      return audience === "talent" ? "Deine Reise ist angelegt." : "Mission angelegt.";
    case "GREETER_ASSIGNED":
      return audience === "talent"
        ? `${g} wird dich abholen.`
        : `${g} übernimmt die Begleitung.`;
    case "GREETER_UNASSIGNED":
      return "Greeter-Zuweisung wurde gelöst.";
    case "FLIGHT_DELAYED":
      return audience === "talent"
        ? "Wir haben deine neue Ankunftszeit gesehen."
        : `Flug verspätet — ${g} ist informiert.`;
    case "FLIGHT_INFO_UPDATED":
      return "Fluginfo aktualisiert.";
    case "TALENT_PICKED_UP":
      return audience === "talent"
        ? "Du bist abgeholt."
        : `${g} hat ${t} am Flughafen abgeholt.`;
    case "EN_ROUTE":
      return audience === "talent"
        ? "Ihr seid unterwegs zur Unterkunft."
        : `${g} ist mit ${t} unterwegs zur Unterkunft.`;
    case "HANDOVER_COMPLETED":
      return audience === "talent"
        ? "Angekommen. Ruh dich aus."
        : `Übergabe an ${t} abgeschlossen.`;
    case "APARTMENT_KEYS_TRANSFERRED":
      return "Schlüssel übergeben.";
    case "CHECKIN_COMPLETED":
      return "Check-in abgeschlossen.";
    case "BLOCKER_SET":
      return audience === "talent" ? "Wir warten noch auf etwas." : `Blocker: ${event.title ?? "ohne Beschreibung"}`;
    case "BLOCKER_RESOLVED":
      return audience === "talent" ? "Erledigt." : `Blocker gelöst: ${event.title ?? ""}`.trim();
    case "DOCUMENT_RECEIVED":
      return audience === "talent" ? "Dokument ist da." : `Dokument erhalten: ${event.title ?? ""}`.trim();
    default:
      return event.title ?? event.kind;
  }
}

/**
 * Welcher Tap-Button ist als Nächstes dran?
 * Reihenfolge: pick-up → en-route → handover.
 */
export type GreeterPrimaryTap = "PICK_UP" | "EN_ROUTE" | "HANDOVER" | "DONE";

export function nextGreeterTap(eventKinds: string[]): GreeterPrimaryTap {
  const set = new Set(eventKinds);
  if (set.has("HANDOVER_COMPLETED")) return "DONE";
  if (set.has("EN_ROUTE")) return "HANDOVER";
  if (set.has("TALENT_PICKED_UP")) return "EN_ROUTE";
  return "PICK_UP";
}

export const TAP_LABELS: Record<GreeterPrimaryTap, { label: string; kind: string; title: string }> = {
  PICK_UP: { label: "Abgeholt", kind: "TALENT_PICKED_UP", title: "Talent am Flughafen abgeholt" },
  EN_ROUTE: { label: "Unterwegs zur Unterkunft", kind: "EN_ROUTE", title: "Unterwegs zur Unterkunft" },
  HANDOVER: { label: "Übergabe erledigt", kind: "HANDOVER_COMPLETED", title: "Übergabe abgeschlossen" },
  DONE: { label: "Alles erledigt", kind: "HANDOVER_COMPLETED", title: "" },
};
