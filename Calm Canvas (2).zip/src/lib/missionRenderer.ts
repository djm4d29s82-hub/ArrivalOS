// Meaning Layer — pure code → sentence mapping per view.
//
// HARD RULES (enforced by review):
//  - Renderer ist ein reiner Code-→-Sentence-Mapper. Nichts anderes.
//  - No imports beyond the kernel types in this file.
//  - No if/else, switch, time comparisons, Date imports, or fallback logic
//    beyond "code missing in map → output the raw code so drift is visible".
//  - No reads of mission_events, documents, dates, or any other source.
//  - Keine Bedingungen, keine Zeitlogik, keine Datenquellen.
//
// KERNEL STABILITY (QA-Invariante):
//  Gleiche Kernel-Codes MÜSSEN strukturell identische Ausgabe erzeugen
//  (1 state-Satz, 0–1 next-Satz, 0–N blocker-Sätze). Unterschiede zwischen
//  Views dürfen ausschließlich Sprache/Subjekt/Person betreffen — niemals
//  Struktur, Reihenfolge oder Anzahl der Sätze.
//
// Same kernel → same set of sentences, only worded for the audience.

import type { MissionKernel, StateCode, NextCode, BlockerCode } from "./missionKernel";

export type ViewKey = "talent" | "greeter" | "ops";

export type KernelSentences = {
  state: string;
  next: string | null;
  blockers: string[];
};

// {name} = subject (talent name in greeter/ops, ignored in talent view)
// Verbs are deliberately in active present tense — that is the only
// active-presence signal the system has without animations.
const STATE_MAP: Record<ViewKey, Partial<Record<StateCode, string>>> = {
  talent: {
    mission_draft: "Wir bereiten alles für dich vor",
    mission_confirmed: "Alles ist vorbereitet",
    mission_in_progress: "Deine Reise läuft",
    mission_completed: "Du bist angekommen",
    mission_cancelled: "Diese Reise wurde abgesagt",
    greeter_assigned: "Dein Greeter steht fest",
    greeter_unterwegs: "Dein Greeter ist zu dir unterwegs",
    talent_gelandet: "Du bist gelandet",
    gepaeck: "Dein Gepäck ist abgeholt",
    fahrt: "Die Fahrt läuft",
    wohnung_uebergeben: "Deine Wohnung ist übergeben",
    arrival: "Du bist am Flughafen abgeholt",
    anmeldung: "Du bist im Bürgeramt angemeldet",
    created: "Deine Mission ist angelegt",
    note: "Es gibt eine neue Notiz",
  },
  greeter: {
    mission_draft: "{name} ist im Entwurf",
    mission_confirmed: "{name} ist bestätigt — alles ist vorbereitet",
    mission_in_progress: "{name} ist mit dir unterwegs",
    mission_completed: "{name} ist angekommen",
    mission_cancelled: "{name} wurde abgesagt",
    greeter_assigned: "Du bist {name} zugewiesen",
    greeter_unterwegs: "Du bist zu {name} unterwegs",
    talent_gelandet: "{name} ist gelandet",
    gepaeck: "{name}s Gepäck ist abgeholt",
    fahrt: "Die Fahrt mit {name} läuft",
    wohnung_uebergeben: "{name}s Wohnung ist übergeben",
    arrival: "{name} ist am Flughafen abgeholt",
    anmeldung: "{name} ist im Bürgeramt angemeldet",
    created: "{name}s Mission ist angelegt",
    note: "Neue Notiz zu {name}",
  },
  ops: {
    mission_draft: "{name} ist im Entwurf",
    mission_confirmed: "{name} ist bestätigt",
    mission_in_progress: "{name} läuft",
    mission_completed: "{name} ist angekommen",
    mission_cancelled: "{name} wurde abgesagt",
    greeter_assigned: "Greeter steht für {name} fest",
    greeter_unterwegs: "Greeter ist zu {name} unterwegs",
    talent_gelandet: "{name} ist gelandet",
    gepaeck: "{name}s Gepäck ist abgeholt",
    fahrt: "Fahrt mit {name} läuft",
    wohnung_uebergeben: "{name}s Wohnung ist übergeben",
    arrival: "{name} ist abgeholt",
    anmeldung: "{name} ist angemeldet",
    created: "{name}s Mission ist angelegt",
    note: "Notiz zu {name}",
  },
};

const NEXT_MAP: Record<ViewKey, Partial<Record<NextCode, string>>> = {
  talent: {
    greeter_assigned: "Dein Greeter wird dir zugeteilt",
    greeter_unterwegs: "Dein Greeter macht sich auf den Weg",
    talent_gelandet: "Deine Landung steht bevor",
    gepaeck: "Gepäck wird abgeholt",
    fahrt: "Die Fahrt steht bevor",
    wohnung_uebergeben: "Wohnungsübergabe steht an",
    arrival: "Du wirst am Flughafen abgeholt",
    anmeldung: "Anmeldung im Bürgeramt steht an",
    documents_awaited: "Wir warten auf deine Dokumente",
  },
  greeter: {
    greeter_assigned: "Du wirst {name} zugeteilt",
    greeter_unterwegs: "Mach dich zu {name} auf den Weg",
    talent_gelandet: "{name} landet gleich",
    gepaeck: "{name}s Gepäck wird abgeholt",
    fahrt: "Fahrt mit {name} steht bevor",
    wohnung_uebergeben: "Wohnungsübergabe mit {name} steht an",
    arrival: "{name} wird abgeholt",
    anmeldung: "Anmeldung mit {name} steht an",
    documents_awaited: "Wir warten auf {name}s Dokumente",
  },
  ops: {
    greeter_assigned: "Greeter wird {name} zugeteilt",
    greeter_unterwegs: "Greeter macht sich zu {name} auf den Weg",
    talent_gelandet: "{name} landet gleich",
    gepaeck: "Gepäckabholung steht an",
    fahrt: "Fahrt mit {name} steht bevor",
    wohnung_uebergeben: "Wohnungsübergabe steht an",
    arrival: "Abholung am Flughafen steht an",
    anmeldung: "Anmeldung im Bürgeramt steht an",
    documents_awaited: "System wartet auf Dokumente von {name}",
  },
};

const BLOCKER_MAP: Record<ViewKey, Partial<Record<BlockerCode, string>>> = {
  talent: {
    passport_missing: "Dein Reisepass fehlt",
    tax_id_missing: "Deine Steuer-ID fehlt",
    visa_missing: "Dein Visum fehlt",
    contract_missing: "Dein Vertrag fehlt",
    insurance_missing: "Deine Versicherung fehlt",
    other_missing: "Ein Dokument fehlt",
    plus_n_more: "{n} weitere fehlen",
  },
  greeter: {
    passport_missing: "Reisepass von {name} fehlt",
    tax_id_missing: "Steuer-ID von {name} fehlt",
    visa_missing: "Visum von {name} fehlt",
    contract_missing: "Vertrag von {name} fehlt",
    insurance_missing: "Versicherung von {name} fehlt",
    other_missing: "Ein Dokument von {name} fehlt",
    plus_n_more: "{n} weitere fehlen",
  },
  ops: {
    passport_missing: "Reisepass fehlt",
    tax_id_missing: "Steuer-ID fehlt",
    visa_missing: "Visum fehlt",
    contract_missing: "Vertrag fehlt",
    insurance_missing: "Versicherung fehlt",
    other_missing: "Dokument fehlt",
    plus_n_more: "{n} weitere fehlen",
  },
};

function sub(template: string, name: string, count: number): string {
  return template.replaceAll("{name}", name).replaceAll("{n}", String(count));
}

export function renderKernel(
  kernel: MissionKernel,
  view: ViewKey,
  subjectName?: string,
): KernelSentences {
  const name = subjectName ?? "";
  const state = sub(STATE_MAP[view][kernel.state.code] ?? kernel.state.code, name, 0);
  const next = kernel.next
    ? sub(NEXT_MAP[view][kernel.next.code] ?? kernel.next.code, name, 0)
    : null;
  const blockers = kernel.blockers.map((b) =>
    sub(BLOCKER_MAP[view][b.code] ?? b.code, name, b.count ?? 0),
  );
  return { state, next, blockers };
}

export const renderTalent = (kernel: MissionKernel) => renderKernel(kernel, "talent");
export const renderGreeter = (kernel: MissionKernel, talentName: string) =>
  renderKernel(kernel, "greeter", talentName);
export const renderOps = (kernel: MissionKernel, subjectName: string) =>
  renderKernel(kernel, "ops", subjectName);
