export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      blockers: {
        Row: {
          created_at: string
          created_by: string
          id: string
          is_demo: boolean
          mission_id: string
          owner_role: Database["public"]["Enums"]["app_role"] | null
          owner_user_id: string | null
          payload: Json
          reason: string
          resolved_at: string | null
          resolved_by: string | null
        }
        Insert: {
          created_at?: string
          created_by: string
          id?: string
          is_demo?: boolean
          mission_id: string
          owner_role?: Database["public"]["Enums"]["app_role"] | null
          owner_user_id?: string | null
          payload?: Json
          reason: string
          resolved_at?: string | null
          resolved_by?: string | null
        }
        Update: {
          created_at?: string
          created_by?: string
          id?: string
          is_demo?: boolean
          mission_id?: string
          owner_role?: Database["public"]["Enums"]["app_role"] | null
          owner_user_id?: string | null
          payload?: Json
          reason?: string
          resolved_at?: string | null
          resolved_by?: string | null
        }
        Relationships: []
      }
      companies: {
        Row: {
          city: string | null
          contact_email: string | null
          created_at: string
          id: string
          is_demo: boolean
          name: string
        }
        Insert: {
          city?: string | null
          contact_email?: string | null
          created_at?: string
          id?: string
          is_demo?: boolean
          name: string
        }
        Update: {
          city?: string | null
          contact_email?: string | null
          created_at?: string
          id?: string
          is_demo?: boolean
          name?: string
        }
        Relationships: []
      }
      company_members: {
        Row: {
          company_id: string
          is_demo: boolean
          user_id: string
        }
        Insert: {
          company_id: string
          is_demo?: boolean
          user_id: string
        }
        Update: {
          company_id?: string
          is_demo?: boolean
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "company_members_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      documents: {
        Row: {
          created_at: string
          id: string
          is_demo: boolean
          kind: string
          mission_id: string | null
          owner_user_id: string
          status: string
          storage_path: string | null
          title: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_demo?: boolean
          kind: string
          mission_id?: string | null
          owner_user_id: string
          status?: string
          storage_path?: string | null
          title: string
        }
        Update: {
          created_at?: string
          id?: string
          is_demo?: boolean
          kind?: string
          mission_id?: string | null
          owner_user_id?: string
          status?: string
          storage_path?: string | null
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "documents_mission_id_fkey"
            columns: ["mission_id"]
            isOneToOne: false
            referencedRelation: "missions"
            referencedColumns: ["id"]
          },
        ]
      }
      greeters: {
        Row: {
          available: boolean
          bio: string | null
          city: string
          created_at: string
          is_demo: boolean
          languages: string[]
          user_id: string
        }
        Insert: {
          available?: boolean
          bio?: string | null
          city?: string
          created_at?: string
          is_demo?: boolean
          languages?: string[]
          user_id: string
        }
        Update: {
          available?: boolean
          bio?: string | null
          city?: string
          created_at?: string
          is_demo?: boolean
          languages?: string[]
          user_id?: string
        }
        Relationships: []
      }
      invoices: {
        Row: {
          amount_cents: number
          company_id: string
          created_at: string
          currency: string
          id: string
          issued_at: string | null
          mission_id: string | null
          status: string
        }
        Insert: {
          amount_cents?: number
          company_id: string
          created_at?: string
          currency?: string
          id?: string
          issued_at?: string | null
          mission_id?: string | null
          status?: string
        }
        Update: {
          amount_cents?: number
          company_id?: string
          created_at?: string
          currency?: string
          id?: string
          issued_at?: string | null
          mission_id?: string | null
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "invoices_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "invoices_mission_id_fkey"
            columns: ["mission_id"]
            isOneToOne: false
            referencedRelation: "missions"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          body: string
          created_at: string
          from_user_id: string
          id: string
          is_demo: boolean
          mission_id: string
        }
        Insert: {
          body: string
          created_at?: string
          from_user_id: string
          id?: string
          is_demo?: boolean
          mission_id: string
        }
        Update: {
          body?: string
          created_at?: string
          from_user_id?: string
          id?: string
          is_demo?: boolean
          mission_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_mission_id_fkey"
            columns: ["mission_id"]
            isOneToOne: false
            referencedRelation: "missions"
            referencedColumns: ["id"]
          },
        ]
      }
      mission_assignments: {
        Row: {
          assigned_at: string
          assigned_by: string | null
          id: string
          is_demo: boolean
          mission_id: string
          role: Database["public"]["Enums"]["app_role"]
          unassigned_at: string | null
          user_id: string
        }
        Insert: {
          assigned_at?: string
          assigned_by?: string | null
          id?: string
          is_demo?: boolean
          mission_id: string
          role: Database["public"]["Enums"]["app_role"]
          unassigned_at?: string | null
          user_id: string
        }
        Update: {
          assigned_at?: string
          assigned_by?: string | null
          id?: string
          is_demo?: boolean
          mission_id?: string
          role?: Database["public"]["Enums"]["app_role"]
          unassigned_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
      mission_events: {
        Row: {
          actor_role: Database["public"]["Enums"]["app_role"] | null
          body: string | null
          created_at: string
          created_by: string | null
          id: string
          is_demo: boolean
          kind: string
          mission_id: string
          payload: Json
          title: string
        }
        Insert: {
          actor_role?: Database["public"]["Enums"]["app_role"] | null
          body?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          is_demo?: boolean
          kind: string
          mission_id: string
          payload?: Json
          title: string
        }
        Update: {
          actor_role?: Database["public"]["Enums"]["app_role"] | null
          body?: string | null
          created_at?: string
          created_by?: string | null
          id?: string
          is_demo?: boolean
          kind?: string
          mission_id?: string
          payload?: Json
          title?: string
        }
        Relationships: [
          {
            foreignKeyName: "mission_events_mission_id_fkey"
            columns: ["mission_id"]
            isOneToOne: false
            referencedRelation: "missions"
            referencedColumns: ["id"]
          },
        ]
      }
      missions: {
        Row: {
          accommodation_address: string | null
          actual_arrival: string | null
          airline: string | null
          arrival_airport: string | null
          arrival_gate: string | null
          arrival_terminal: string | null
          city: string
          company_id: string | null
          created_at: string
          ends_at: string | null
          flight_number: string | null
          greeter_id: string | null
          id: string
          is_demo: boolean
          scheduled_arrival: string | null
          starts_at: string | null
          status: Database["public"]["Enums"]["mission_status"]
          summary: string | null
          talent_id: string
          updated_at: string
        }
        Insert: {
          accommodation_address?: string | null
          actual_arrival?: string | null
          airline?: string | null
          arrival_airport?: string | null
          arrival_gate?: string | null
          arrival_terminal?: string | null
          city: string
          company_id?: string | null
          created_at?: string
          ends_at?: string | null
          flight_number?: string | null
          greeter_id?: string | null
          id?: string
          is_demo?: boolean
          scheduled_arrival?: string | null
          starts_at?: string | null
          status?: Database["public"]["Enums"]["mission_status"]
          summary?: string | null
          talent_id: string
          updated_at?: string
        }
        Update: {
          accommodation_address?: string | null
          actual_arrival?: string | null
          airline?: string | null
          arrival_airport?: string | null
          arrival_gate?: string | null
          arrival_terminal?: string | null
          city?: string
          company_id?: string | null
          created_at?: string
          ends_at?: string | null
          flight_number?: string | null
          greeter_id?: string | null
          id?: string
          is_demo?: boolean
          scheduled_arrival?: string | null
          starts_at?: string | null
          status?: Database["public"]["Enums"]["mission_status"]
          summary?: string | null
          talent_id?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "missions_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          avatar_url: string | null
          created_at: string
          full_name: string | null
          id: string
          is_demo: boolean
          locale: string
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id: string
          is_demo?: boolean
          locale?: string
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          full_name?: string | null
          id?: string
          is_demo?: boolean
          locale?: string
          updated_at?: string
        }
        Relationships: []
      }
      sops: {
        Row: {
          audience: Database["public"]["Enums"]["app_role"]
          body: string
          created_at: string
          id: string
          title: string
        }
        Insert: {
          audience?: Database["public"]["Enums"]["app_role"]
          body: string
          created_at?: string
          id?: string
          title: string
        }
        Update: {
          audience?: Database["public"]["Enums"]["app_role"]
          body?: string
          created_at?: string
          id?: string
          title?: string
        }
        Relationships: []
      }
      talents: {
        Row: {
          arrival_date: string | null
          city: string | null
          company_id: string | null
          created_at: string
          home_country: string | null
          is_demo: boolean
          languages: string[]
          photo_url: string | null
          recruiter_notes: string | null
          user_id: string
        }
        Insert: {
          arrival_date?: string | null
          city?: string | null
          company_id?: string | null
          created_at?: string
          home_country?: string | null
          is_demo?: boolean
          languages?: string[]
          photo_url?: string | null
          recruiter_notes?: string | null
          user_id: string
        }
        Update: {
          arrival_date?: string | null
          city?: string | null
          company_id?: string | null
          created_at?: string
          home_country?: string | null
          is_demo?: boolean
          languages?: string[]
          photo_url?: string | null
          recruiter_notes?: string | null
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "talents_company_id_fkey"
            columns: ["company_id"]
            isOneToOne: false
            referencedRelation: "companies"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          is_demo: boolean
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          is_demo?: boolean
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          is_demo?: boolean
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_view_mission: {
        Args: { _mission_id: string; _user_id: string }
        Returns: boolean
      }
      current_role_names: { Args: never; Returns: string[] }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_admin: { Args: { _user_id: string }; Returns: boolean }
      user_company_ids: { Args: { _user_id: string }; Returns: string[] }
    }
    Enums: {
      app_role: "talent" | "greeter" | "company" | "admin"
      mission_status:
        | "draft"
        | "confirmed"
        | "in_progress"
        | "completed"
        | "cancelled"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["talent", "greeter", "company", "admin"],
      mission_status: [
        "draft",
        "confirmed",
        "in_progress",
        "completed",
        "cancelled",
      ],
    },
  },
} as const
